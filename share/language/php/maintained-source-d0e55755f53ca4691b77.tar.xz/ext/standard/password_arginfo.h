/**
 * @file password_arginfo.h
 * @brief Maintain the original PHP and Zend implementation for the standalone Wasm runtime.
 * @details Original algorithms, licensing and copyright remain intact.
 * Target-specific behavior is documented by the adjacent port manifest.
 */
/* This is a generated file, edit the .stub.php file instead.
 * Stub hash: aab38646ace967e985c348b78251474693da95a7 */

static void register_password_symbols(int module_number)
{
    REGISTER_STRING_CONSTANT("PASSWORD_DEFAULT", "2y", CONST_PERSISTENT);
    REGISTER_STRING_CONSTANT("PASSWORD_BCRYPT", "2y", CONST_PERSISTENT);
    REGISTER_LONG_CONSTANT("PASSWORD_BCRYPT_DEFAULT_COST", PHP_PASSWORD_BCRYPT_COST, CONST_PERSISTENT);
#if defined(HAVE_ARGON2LIB)
    REGISTER_STRING_CONSTANT("PASSWORD_ARGON2I", "argon2i", CONST_PERSISTENT);
#endif
#if defined(HAVE_ARGON2LIB)
    REGISTER_STRING_CONSTANT("PASSWORD_ARGON2ID", "argon2id", CONST_PERSISTENT);
#endif
#if defined(HAVE_ARGON2LIB)
    REGISTER_STRING_CONSTANT("PASSWORD_ARGON2_PROVIDER", "standard", CONST_PERSISTENT);
#endif
#if defined(HAVE_ARGON2LIB)
    REGISTER_LONG_CONSTANT("PASSWORD_ARGON2_DEFAULT_MEMORY_COST", PHP_PASSWORD_ARGON2_MEMORY_COST, CONST_PERSISTENT);
#endif
#if defined(HAVE_ARGON2LIB)
    REGISTER_LONG_CONSTANT("PASSWORD_ARGON2_DEFAULT_TIME_COST", PHP_PASSWORD_ARGON2_TIME_COST, CONST_PERSISTENT);
#endif
#if defined(HAVE_ARGON2LIB)
    REGISTER_LONG_CONSTANT("PASSWORD_ARGON2_DEFAULT_THREADS", PHP_PASSWORD_ARGON2_THREADS, CONST_PERSISTENT);
#endif
}
