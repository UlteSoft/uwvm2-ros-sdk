/**
 * @file php_reflection_arginfo.h
 * @brief Maintain the original PHP and Zend implementation for the standalone Wasm runtime.
 * @details Original algorithms, licensing and copyright remain intact.
 * Target-specific behavior is documented by the adjacent port manifest.
 */
/* This is a generated file, edit the .stub.php file instead.
 * Stub hash: 0f56ad99157c52b2f259fa6607872de6a134c1b5 */

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(arginfo_class_Reflection_getModifierNames, 0, 1, IS_ARRAY, 0)
ZEND_ARG_TYPE_INFO(0, modifiers, IS_LONG, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionFunctionAbstract___clone, 0, 0, IS_VOID, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(
    arginfo_class_ReflectionFunctionAbstract_inNamespace, 0, 0, _IS_BOOL, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionFunctionAbstract_isClosure arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionFunctionAbstract_isDeprecated arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionFunctionAbstract_isInternal arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionFunctionAbstract_isUserDefined arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionFunctionAbstract_isGenerator arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionFunctionAbstract_isVariadic arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionFunctionAbstract_isStatic arginfo_class_ReflectionFunctionAbstract_inNamespace

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(
    arginfo_class_ReflectionFunctionAbstract_getClosureThis, 0, 0, IS_OBJECT, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_OBJ_INFO_EX(
    arginfo_class_ReflectionFunctionAbstract_getClosureScopeClass, 0, 0, ReflectionClass, 1)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionFunctionAbstract_getClosureCalledClass                                                 \
    arginfo_class_ReflectionFunctionAbstract_getClosureScopeClass

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(
    arginfo_class_ReflectionFunctionAbstract_getClosureUsedVariables, 0, 0, IS_ARRAY, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_MASK_EX(arginfo_class_ReflectionFunctionAbstract_getDocComment,
                                                  0,
                                                  0,
                                                  MAY_BE_STRING | MAY_BE_FALSE)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_MASK_EX(arginfo_class_ReflectionFunctionAbstract_getEndLine,
                                                  0,
                                                  0,
                                                  MAY_BE_LONG | MAY_BE_FALSE)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_OBJ_INFO_EX(
    arginfo_class_ReflectionFunctionAbstract_getExtension, 0, 0, ReflectionExtension, 1)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionFunctionAbstract_getExtensionName arginfo_class_ReflectionFunctionAbstract_getDocComment

#define arginfo_class_ReflectionFunctionAbstract_getFileName arginfo_class_ReflectionFunctionAbstract_getDocComment

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionFunctionAbstract_getName, 0, 0, IS_STRING, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionFunctionAbstract_getNamespaceName arginfo_class_ReflectionFunctionAbstract_getName

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(
    arginfo_class_ReflectionFunctionAbstract_getNumberOfParameters, 0, 0, IS_LONG, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionFunctionAbstract_getNumberOfRequiredParameters                                         \
    arginfo_class_ReflectionFunctionAbstract_getNumberOfParameters

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(
    arginfo_class_ReflectionFunctionAbstract_getParameters, 0, 0, IS_ARRAY, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionFunctionAbstract_getShortName arginfo_class_ReflectionFunctionAbstract_getName

#define arginfo_class_ReflectionFunctionAbstract_getStartLine arginfo_class_ReflectionFunctionAbstract_getEndLine

#define arginfo_class_ReflectionFunctionAbstract_getStaticVariables                                                    \
    arginfo_class_ReflectionFunctionAbstract_getParameters

#define arginfo_class_ReflectionFunctionAbstract_returnsReference arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionFunctionAbstract_hasReturnType arginfo_class_ReflectionFunctionAbstract_inNamespace

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_OBJ_INFO_EX(
    arginfo_class_ReflectionFunctionAbstract_getReturnType, 0, 0, ReflectionType, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(
    arginfo_class_ReflectionFunctionAbstract_hasTentativeReturnType, 0, 0, _IS_BOOL, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_OBJ_INFO_EX(
    arginfo_class_ReflectionFunctionAbstract_getTentativeReturnType, 0, 0, ReflectionType, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionFunctionAbstract_getAttributes, 0, 0, IS_ARRAY, 0)
ZEND_ARG_TYPE_INFO_WITH_DEFAULT_VALUE(0, name, IS_STRING, 1, "null")
ZEND_ARG_TYPE_INFO_WITH_DEFAULT_VALUE(0, flags, IS_LONG, 0, "0")
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_ReflectionFunction___construct, 0, 0, 1)
ZEND_ARG_OBJ_TYPE_MASK(0, function, Closure, MAY_BE_STRING, NULL)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionFunction___toString, 0, 0, IS_STRING, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionFunction_isAnonymous arginfo_class_ReflectionFunctionAbstract_hasTentativeReturnType

#define arginfo_class_ReflectionFunction_isDisabled arginfo_class_ReflectionFunctionAbstract_inNamespace

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionFunction_invoke, 0, 0, IS_MIXED, 0)
ZEND_ARG_VARIADIC_TYPE_INFO(0, args, IS_MIXED, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionFunction_invokeArgs, 0, 1, IS_MIXED, 0)
ZEND_ARG_TYPE_INFO(0, args, IS_ARRAY, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_OBJ_INFO_EX(arginfo_class_ReflectionFunction_getClosure, 0, 0, Closure, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_ReflectionGenerator___construct, 0, 0, 1)
ZEND_ARG_OBJ_INFO(0, generator, Generator, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionGenerator_getExecutingLine                                                             \
    arginfo_class_ReflectionFunctionAbstract_getNumberOfParameters

#define arginfo_class_ReflectionGenerator_getExecutingFile arginfo_class_ReflectionFunctionAbstract_getName

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionGenerator_getTrace, 0, 0, IS_ARRAY, 0)
ZEND_ARG_TYPE_INFO_WITH_DEFAULT_VALUE(0, options, IS_LONG, 0, "DEBUG_BACKTRACE_PROVIDE_OBJECT")
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_OBJ_INFO_EX(
    arginfo_class_ReflectionGenerator_getFunction, 0, 0, ReflectionFunctionAbstract, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionGenerator_getThis arginfo_class_ReflectionFunctionAbstract_getClosureThis

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_OBJ_INFO_EX(
    arginfo_class_ReflectionGenerator_getExecutingGenerator, 0, 0, Generator, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionGenerator_isClosed arginfo_class_ReflectionFunctionAbstract_hasTentativeReturnType

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_ReflectionMethod___construct, 0, 0, 1)
ZEND_ARG_TYPE_MASK(0, objectOrMethod, MAY_BE_OBJECT | MAY_BE_STRING, NULL)
ZEND_ARG_TYPE_INFO_WITH_DEFAULT_VALUE(0, method, IS_STRING, 1, "null")
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionMethod_createFromMethodName, 0, 1, IS_STATIC, 0)
ZEND_ARG_TYPE_INFO(0, method, IS_STRING, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionMethod___toString arginfo_class_ReflectionFunction___toString

#define arginfo_class_ReflectionMethod_isPublic arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionMethod_isPrivate arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionMethod_isProtected arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionMethod_isAbstract arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionMethod_isFinal arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionMethod_isConstructor arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionMethod_isDestructor arginfo_class_ReflectionFunctionAbstract_inNamespace

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_OBJ_INFO_EX(arginfo_class_ReflectionMethod_getClosure, 0, 0, Closure, 0)
ZEND_ARG_TYPE_INFO_WITH_DEFAULT_VALUE(0, object, IS_OBJECT, 1, "null")
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionMethod_getModifiers arginfo_class_ReflectionFunctionAbstract_getNumberOfParameters

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionMethod_invoke, 0, 1, IS_MIXED, 0)
ZEND_ARG_TYPE_INFO(0, object, IS_OBJECT, 1)
ZEND_ARG_VARIADIC_TYPE_INFO(0, args, IS_MIXED, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionMethod_invokeArgs, 0, 2, IS_MIXED, 0)
ZEND_ARG_TYPE_INFO(0, object, IS_OBJECT, 1)
ZEND_ARG_TYPE_INFO(0, args, IS_ARRAY, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_OBJ_INFO_EX(
    arginfo_class_ReflectionMethod_getDeclaringClass, 0, 0, ReflectionClass, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_OBJ_INFO_EX(arginfo_class_ReflectionMethod_getPrototype, 0, 0, ReflectionMethod, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionMethod_hasPrototype arginfo_class_ReflectionFunctionAbstract_hasTentativeReturnType

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionMethod_setAccessible, 0, 1, IS_VOID, 0)
ZEND_ARG_TYPE_INFO(0, accessible, _IS_BOOL, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionClass___clone arginfo_class_ReflectionFunctionAbstract___clone

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_ReflectionClass___construct, 0, 0, 1)
ZEND_ARG_TYPE_MASK(0, objectOrClass, MAY_BE_OBJECT | MAY_BE_STRING, NULL)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionClass___toString arginfo_class_ReflectionFunction___toString

#define arginfo_class_ReflectionClass_getName arginfo_class_ReflectionFunctionAbstract_getName

#define arginfo_class_ReflectionClass_isInternal arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionClass_isUserDefined arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionClass_isAnonymous arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionClass_isInstantiable arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionClass_isCloneable arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionClass_getFileName arginfo_class_ReflectionFunctionAbstract_getDocComment

#define arginfo_class_ReflectionClass_getStartLine arginfo_class_ReflectionFunctionAbstract_getEndLine

#define arginfo_class_ReflectionClass_getEndLine arginfo_class_ReflectionFunctionAbstract_getEndLine

#define arginfo_class_ReflectionClass_getDocComment arginfo_class_ReflectionFunctionAbstract_getDocComment

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_OBJ_INFO_EX(
    arginfo_class_ReflectionClass_getConstructor, 0, 0, ReflectionMethod, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionClass_hasMethod, 0, 1, _IS_BOOL, 0)
ZEND_ARG_TYPE_INFO(0, name, IS_STRING, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_OBJ_INFO_EX(arginfo_class_ReflectionClass_getMethod, 0, 1, ReflectionMethod, 0)
ZEND_ARG_TYPE_INFO(0, name, IS_STRING, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionClass_getMethods, 0, 0, IS_ARRAY, 0)
ZEND_ARG_TYPE_INFO_WITH_DEFAULT_VALUE(0, filter, IS_LONG, 1, "null")
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionClass_hasProperty arginfo_class_ReflectionClass_hasMethod

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_OBJ_INFO_EX(arginfo_class_ReflectionClass_getProperty, 0, 1, ReflectionProperty, 0)
ZEND_ARG_TYPE_INFO(0, name, IS_STRING, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionClass_getProperties arginfo_class_ReflectionClass_getMethods

#define arginfo_class_ReflectionClass_hasConstant arginfo_class_ReflectionClass_hasMethod

#define arginfo_class_ReflectionClass_getConstants arginfo_class_ReflectionClass_getMethods

#define arginfo_class_ReflectionClass_getReflectionConstants arginfo_class_ReflectionClass_getMethods

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionClass_getConstant, 0, 1, IS_MIXED, 0)
ZEND_ARG_TYPE_INFO(0, name, IS_STRING, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_OBJ_TYPE_MASK_EX(
    arginfo_class_ReflectionClass_getReflectionConstant, 0, 1, ReflectionClassConstant, MAY_BE_FALSE)
ZEND_ARG_TYPE_INFO(0, name, IS_STRING, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionClass_getInterfaces arginfo_class_ReflectionFunctionAbstract_getParameters

#define arginfo_class_ReflectionClass_getInterfaceNames arginfo_class_ReflectionFunctionAbstract_getParameters

#define arginfo_class_ReflectionClass_isInterface arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionClass_getTraits arginfo_class_ReflectionFunctionAbstract_getParameters

#define arginfo_class_ReflectionClass_getTraitNames arginfo_class_ReflectionFunctionAbstract_getParameters

#define arginfo_class_ReflectionClass_getTraitAliases arginfo_class_ReflectionFunctionAbstract_getParameters

#define arginfo_class_ReflectionClass_isTrait arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionClass_isEnum arginfo_class_ReflectionFunctionAbstract_hasTentativeReturnType

#define arginfo_class_ReflectionClass_isAbstract arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionClass_isFinal arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionClass_isReadOnly arginfo_class_ReflectionFunctionAbstract_hasTentativeReturnType

#define arginfo_class_ReflectionClass_getModifiers arginfo_class_ReflectionFunctionAbstract_getNumberOfParameters

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionClass_isInstance, 0, 1, _IS_BOOL, 0)
ZEND_ARG_TYPE_INFO(0, object, IS_OBJECT, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionClass_newInstance, 0, 0, IS_OBJECT, 0)
ZEND_ARG_VARIADIC_TYPE_INFO(0, args, IS_MIXED, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(
    arginfo_class_ReflectionClass_newInstanceWithoutConstructor, 0, 0, IS_OBJECT, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionClass_newInstanceArgs, 0, 0, IS_OBJECT, 1)
ZEND_ARG_TYPE_INFO_WITH_DEFAULT_VALUE(0, args, IS_ARRAY, 0, "[]")
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionClass_newLazyGhost, 0, 1, IS_OBJECT, 0)
ZEND_ARG_TYPE_INFO(0, initializer, IS_CALLABLE, 0)
ZEND_ARG_TYPE_INFO_WITH_DEFAULT_VALUE(0, options, IS_LONG, 0, "0")
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionClass_newLazyProxy, 0, 1, IS_OBJECT, 0)
ZEND_ARG_TYPE_INFO(0, factory, IS_CALLABLE, 0)
ZEND_ARG_TYPE_INFO_WITH_DEFAULT_VALUE(0, options, IS_LONG, 0, "0")
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionClass_resetAsLazyGhost, 0, 2, IS_VOID, 0)
ZEND_ARG_TYPE_INFO(0, object, IS_OBJECT, 0)
ZEND_ARG_TYPE_INFO(0, initializer, IS_CALLABLE, 0)
ZEND_ARG_TYPE_INFO_WITH_DEFAULT_VALUE(0, options, IS_LONG, 0, "0")
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionClass_resetAsLazyProxy, 0, 2, IS_VOID, 0)
ZEND_ARG_TYPE_INFO(0, object, IS_OBJECT, 0)
ZEND_ARG_TYPE_INFO(0, factory, IS_CALLABLE, 0)
ZEND_ARG_TYPE_INFO_WITH_DEFAULT_VALUE(0, options, IS_LONG, 0, "0")
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionClass_initializeLazyObject, 0, 1, IS_OBJECT, 0)
ZEND_ARG_TYPE_INFO(0, object, IS_OBJECT, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionClass_isUninitializedLazyObject, 0, 1, _IS_BOOL, 0)
ZEND_ARG_TYPE_INFO(0, object, IS_OBJECT, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionClass_markLazyObjectAsInitialized arginfo_class_ReflectionClass_initializeLazyObject

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionClass_getLazyInitializer, 0, 1, IS_CALLABLE, 1)
ZEND_ARG_TYPE_INFO(0, object, IS_OBJECT, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_OBJ_TYPE_MASK_EX(
    arginfo_class_ReflectionClass_getParentClass, 0, 0, ReflectionClass, MAY_BE_FALSE)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionClass_isSubclassOf, 0, 1, _IS_BOOL, 0)
ZEND_ARG_OBJ_TYPE_MASK(0, class, ReflectionClass, MAY_BE_STRING, NULL)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionClass_getStaticProperties arginfo_class_ReflectionFunctionAbstract_getParameters

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(
    arginfo_class_ReflectionClass_getStaticPropertyValue, 0, 1, IS_MIXED, 0)
ZEND_ARG_TYPE_INFO(0, name, IS_STRING, 0)
ZEND_ARG_TYPE_INFO(0, default, IS_MIXED, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(
    arginfo_class_ReflectionClass_setStaticPropertyValue, 0, 2, IS_VOID, 0)
ZEND_ARG_TYPE_INFO(0, name, IS_STRING, 0)
ZEND_ARG_TYPE_INFO(0, value, IS_MIXED, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionClass_getDefaultProperties arginfo_class_ReflectionFunctionAbstract_getParameters

#define arginfo_class_ReflectionClass_isIterable arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionClass_isIterateable arginfo_class_ReflectionFunctionAbstract_inNamespace

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionClass_implementsInterface, 0, 1, _IS_BOOL, 0)
ZEND_ARG_OBJ_TYPE_MASK(0, interface, ReflectionClass, MAY_BE_STRING, NULL)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionClass_getExtension arginfo_class_ReflectionFunctionAbstract_getExtension

#define arginfo_class_ReflectionClass_getExtensionName arginfo_class_ReflectionFunctionAbstract_getDocComment

#define arginfo_class_ReflectionClass_inNamespace arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionClass_getNamespaceName arginfo_class_ReflectionFunctionAbstract_getName

#define arginfo_class_ReflectionClass_getShortName arginfo_class_ReflectionFunctionAbstract_getName

#define arginfo_class_ReflectionClass_getAttributes arginfo_class_ReflectionFunctionAbstract_getAttributes

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_ReflectionObject___construct, 0, 0, 1)
ZEND_ARG_TYPE_INFO(0, object, IS_OBJECT, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionProperty___clone arginfo_class_ReflectionFunctionAbstract___clone

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_ReflectionProperty___construct, 0, 0, 2)
ZEND_ARG_TYPE_MASK(0, class, MAY_BE_OBJECT | MAY_BE_STRING, NULL)
ZEND_ARG_TYPE_INFO(0, property, IS_STRING, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionProperty___toString arginfo_class_ReflectionFunction___toString

#define arginfo_class_ReflectionProperty_getName arginfo_class_ReflectionFunctionAbstract_getName

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionProperty_getValue, 0, 0, IS_MIXED, 0)
ZEND_ARG_TYPE_INFO_WITH_DEFAULT_VALUE(0, object, IS_OBJECT, 1, "null")
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionProperty_setValue, 0, 1, IS_VOID, 0)
ZEND_ARG_TYPE_INFO(0, objectOrValue, IS_MIXED, 0)
ZEND_ARG_TYPE_INFO(0, value, IS_MIXED, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionProperty_getRawValue, 0, 1, IS_MIXED, 0)
ZEND_ARG_TYPE_INFO(0, object, IS_OBJECT, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionProperty_setRawValue, 0, 2, IS_VOID, 0)
ZEND_ARG_TYPE_INFO(0, object, IS_OBJECT, 0)
ZEND_ARG_TYPE_INFO(0, value, IS_MIXED, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionProperty_setRawValueWithoutLazyInitialization                                          \
    arginfo_class_ReflectionProperty_setRawValue

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionProperty_skipLazyInitialization, 0, 1, IS_VOID, 0)
ZEND_ARG_TYPE_INFO(0, object, IS_OBJECT, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionProperty_isLazy arginfo_class_ReflectionClass_isUninitializedLazyObject

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionProperty_isInitialized, 0, 0, _IS_BOOL, 0)
ZEND_ARG_TYPE_INFO_WITH_DEFAULT_VALUE(0, object, IS_OBJECT, 1, "null")
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionProperty_isPublic arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionProperty_isPrivate arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionProperty_isProtected arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionProperty_isPrivateSet arginfo_class_ReflectionFunctionAbstract_hasTentativeReturnType

#define arginfo_class_ReflectionProperty_isProtectedSet arginfo_class_ReflectionFunctionAbstract_hasTentativeReturnType

#define arginfo_class_ReflectionProperty_isStatic arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionProperty_isReadOnly arginfo_class_ReflectionFunctionAbstract_hasTentativeReturnType

#define arginfo_class_ReflectionProperty_isDefault arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionProperty_isDynamic arginfo_class_ReflectionFunctionAbstract_hasTentativeReturnType

#define arginfo_class_ReflectionProperty_isAbstract arginfo_class_ReflectionFunctionAbstract_hasTentativeReturnType

#define arginfo_class_ReflectionProperty_isVirtual arginfo_class_ReflectionFunctionAbstract_hasTentativeReturnType

#define arginfo_class_ReflectionProperty_isPromoted arginfo_class_ReflectionFunctionAbstract_hasTentativeReturnType

#define arginfo_class_ReflectionProperty_getModifiers arginfo_class_ReflectionFunctionAbstract_getNumberOfParameters

#define arginfo_class_ReflectionProperty_getDeclaringClass arginfo_class_ReflectionMethod_getDeclaringClass

#define arginfo_class_ReflectionProperty_getDocComment arginfo_class_ReflectionFunctionAbstract_getDocComment

#define arginfo_class_ReflectionProperty_setAccessible arginfo_class_ReflectionMethod_setAccessible

#define arginfo_class_ReflectionProperty_getType arginfo_class_ReflectionFunctionAbstract_getReturnType

#define arginfo_class_ReflectionProperty_getSettableType arginfo_class_ReflectionFunctionAbstract_getTentativeReturnType

#define arginfo_class_ReflectionProperty_hasType arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionProperty_hasDefaultValue arginfo_class_ReflectionFunctionAbstract_hasTentativeReturnType

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionProperty_getDefaultValue, 0, 0, IS_MIXED, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionProperty_getAttributes arginfo_class_ReflectionFunctionAbstract_getAttributes

#define arginfo_class_ReflectionProperty_hasHooks arginfo_class_ReflectionFunctionAbstract_hasTentativeReturnType

#define arginfo_class_ReflectionProperty_getHooks arginfo_class_ReflectionFunctionAbstract_getClosureUsedVariables

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionProperty_hasHook, 0, 1, _IS_BOOL, 0)
ZEND_ARG_OBJ_INFO(0, type, PropertyHookType, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_OBJ_INFO_EX(arginfo_class_ReflectionProperty_getHook, 0, 1, ReflectionMethod, 1)
ZEND_ARG_OBJ_INFO(0, type, PropertyHookType, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionProperty_isFinal arginfo_class_ReflectionFunctionAbstract_hasTentativeReturnType

#define arginfo_class_ReflectionClassConstant___clone arginfo_class_ReflectionFunctionAbstract___clone

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_ReflectionClassConstant___construct, 0, 0, 2)
ZEND_ARG_TYPE_MASK(0, class, MAY_BE_OBJECT | MAY_BE_STRING, NULL)
ZEND_ARG_TYPE_INFO(0, constant, IS_STRING, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionClassConstant___toString arginfo_class_ReflectionFunction___toString

#define arginfo_class_ReflectionClassConstant_getName arginfo_class_ReflectionFunctionAbstract_getName

#define arginfo_class_ReflectionClassConstant_getValue arginfo_class_ReflectionProperty_getDefaultValue

#define arginfo_class_ReflectionClassConstant_isPublic arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionClassConstant_isPrivate arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionClassConstant_isProtected arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionClassConstant_isFinal arginfo_class_ReflectionFunctionAbstract_hasTentativeReturnType

#define arginfo_class_ReflectionClassConstant_getModifiers                                                             \
    arginfo_class_ReflectionFunctionAbstract_getNumberOfParameters

#define arginfo_class_ReflectionClassConstant_getDeclaringClass arginfo_class_ReflectionMethod_getDeclaringClass

#define arginfo_class_ReflectionClassConstant_getDocComment arginfo_class_ReflectionFunctionAbstract_getDocComment

#define arginfo_class_ReflectionClassConstant_getAttributes arginfo_class_ReflectionFunctionAbstract_getAttributes

#define arginfo_class_ReflectionClassConstant_isEnumCase arginfo_class_ReflectionFunctionAbstract_hasTentativeReturnType

#define arginfo_class_ReflectionClassConstant_isDeprecated                                                             \
    arginfo_class_ReflectionFunctionAbstract_hasTentativeReturnType

#define arginfo_class_ReflectionClassConstant_hasType arginfo_class_ReflectionFunctionAbstract_hasTentativeReturnType

#define arginfo_class_ReflectionClassConstant_getType arginfo_class_ReflectionFunctionAbstract_getTentativeReturnType

#define arginfo_class_ReflectionParameter___clone arginfo_class_ReflectionFunctionAbstract___clone

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_ReflectionParameter___construct, 0, 0, 2)
ZEND_ARG_INFO(0, function)
ZEND_ARG_TYPE_MASK(0, param, MAY_BE_LONG | MAY_BE_STRING, NULL)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionParameter___toString arginfo_class_ReflectionFunction___toString

#define arginfo_class_ReflectionParameter_getName arginfo_class_ReflectionFunctionAbstract_getName

#define arginfo_class_ReflectionParameter_isPassedByReference arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionParameter_canBePassedByValue arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionParameter_getDeclaringFunction arginfo_class_ReflectionGenerator_getFunction

#define arginfo_class_ReflectionParameter_getDeclaringClass                                                            \
    arginfo_class_ReflectionFunctionAbstract_getClosureScopeClass

#define arginfo_class_ReflectionParameter_getClass arginfo_class_ReflectionFunctionAbstract_getClosureScopeClass

#define arginfo_class_ReflectionParameter_hasType arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionParameter_getType arginfo_class_ReflectionFunctionAbstract_getReturnType

#define arginfo_class_ReflectionParameter_isArray arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionParameter_isCallable arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionParameter_allowsNull arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionParameter_getPosition arginfo_class_ReflectionFunctionAbstract_getNumberOfParameters

#define arginfo_class_ReflectionParameter_isOptional arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionParameter_isDefaultValueAvailable arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionParameter_getDefaultValue arginfo_class_ReflectionProperty_getDefaultValue

#define arginfo_class_ReflectionParameter_isDefaultValueConstant arginfo_class_ReflectionFunctionAbstract_inNamespace

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(
    arginfo_class_ReflectionParameter_getDefaultValueConstantName, 0, 0, IS_STRING, 1)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionParameter_isVariadic arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionParameter_isPromoted arginfo_class_ReflectionFunctionAbstract_hasTentativeReturnType

#define arginfo_class_ReflectionParameter_getAttributes arginfo_class_ReflectionFunctionAbstract_getAttributes

#define arginfo_class_ReflectionType___clone arginfo_class_ReflectionFunctionAbstract___clone

#define arginfo_class_ReflectionType_allowsNull arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionType___toString arginfo_class_ReflectionFunction___toString

#define arginfo_class_ReflectionNamedType_getName arginfo_class_ReflectionFunctionAbstract_getName

#define arginfo_class_ReflectionNamedType_isBuiltin arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionUnionType_getTypes arginfo_class_ReflectionFunctionAbstract_getClosureUsedVariables

#define arginfo_class_ReflectionIntersectionType_getTypes                                                              \
    arginfo_class_ReflectionFunctionAbstract_getClosureUsedVariables

#define arginfo_class_ReflectionExtension___clone arginfo_class_ReflectionFunctionAbstract___clone

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_ReflectionExtension___construct, 0, 0, 1)
ZEND_ARG_TYPE_INFO(0, name, IS_STRING, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionExtension___toString arginfo_class_ReflectionFunction___toString

#define arginfo_class_ReflectionExtension_getName arginfo_class_ReflectionFunctionAbstract_getName

#define arginfo_class_ReflectionExtension_getVersion arginfo_class_ReflectionParameter_getDefaultValueConstantName

#define arginfo_class_ReflectionExtension_getFunctions arginfo_class_ReflectionFunctionAbstract_getParameters

#define arginfo_class_ReflectionExtension_getConstants arginfo_class_ReflectionFunctionAbstract_getParameters

#define arginfo_class_ReflectionExtension_getINIEntries arginfo_class_ReflectionFunctionAbstract_getParameters

#define arginfo_class_ReflectionExtension_getClasses arginfo_class_ReflectionFunctionAbstract_getParameters

#define arginfo_class_ReflectionExtension_getClassNames arginfo_class_ReflectionFunctionAbstract_getParameters

#define arginfo_class_ReflectionExtension_getDependencies arginfo_class_ReflectionFunctionAbstract_getParameters

ZEND_BEGIN_ARG_WITH_TENTATIVE_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionExtension_info, 0, 0, IS_VOID, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionExtension_isPersistent arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionExtension_isTemporary arginfo_class_ReflectionFunctionAbstract_inNamespace

#define arginfo_class_ReflectionZendExtension___clone arginfo_class_ReflectionFunctionAbstract___clone

#define arginfo_class_ReflectionZendExtension___construct arginfo_class_ReflectionExtension___construct

#define arginfo_class_ReflectionZendExtension___toString arginfo_class_ReflectionFunction___toString

#define arginfo_class_ReflectionZendExtension_getName arginfo_class_ReflectionFunctionAbstract_getName

#define arginfo_class_ReflectionZendExtension_getVersion arginfo_class_ReflectionFunctionAbstract_getName

#define arginfo_class_ReflectionZendExtension_getAuthor arginfo_class_ReflectionFunctionAbstract_getName

#define arginfo_class_ReflectionZendExtension_getURL arginfo_class_ReflectionFunctionAbstract_getName

#define arginfo_class_ReflectionZendExtension_getCopyright arginfo_class_ReflectionFunctionAbstract_getName

ZEND_BEGIN_ARG_WITH_RETURN_OBJ_INFO_EX(arginfo_class_ReflectionReference_fromArrayElement, 0, 2, ReflectionReference, 1)
ZEND_ARG_TYPE_INFO(0, array, IS_ARRAY, 0)
ZEND_ARG_TYPE_MASK(0, key, MAY_BE_LONG | MAY_BE_STRING, NULL)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionReference_getId arginfo_class_ReflectionFunction___toString

#define arginfo_class_ReflectionReference___clone arginfo_class_ReflectionFunctionAbstract___clone

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_ReflectionReference___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionAttribute_getName arginfo_class_ReflectionFunction___toString

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionAttribute_getTarget, 0, 0, IS_LONG, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionAttribute_isRepeated arginfo_class_ReflectionFunctionAbstract_hasTentativeReturnType

#define arginfo_class_ReflectionAttribute_getArguments arginfo_class_ReflectionFunctionAbstract_getClosureUsedVariables

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionAttribute_newInstance, 0, 0, IS_OBJECT, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionAttribute___toString arginfo_class_ReflectionFunction___toString

#define arginfo_class_ReflectionAttribute___clone arginfo_class_ReflectionFunctionAbstract___clone

#define arginfo_class_ReflectionAttribute___construct arginfo_class_ReflectionReference___construct

#define arginfo_class_ReflectionEnum___construct arginfo_class_ReflectionClass___construct

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionEnum_hasCase, 0, 1, _IS_BOOL, 0)
ZEND_ARG_TYPE_INFO(0, name, IS_STRING, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_OBJ_INFO_EX(arginfo_class_ReflectionEnum_getCase, 0, 1, ReflectionEnumUnitCase, 0)
ZEND_ARG_TYPE_INFO(0, name, IS_STRING, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionEnum_getCases arginfo_class_ReflectionFunctionAbstract_getClosureUsedVariables

#define arginfo_class_ReflectionEnum_isBacked arginfo_class_ReflectionFunctionAbstract_hasTentativeReturnType

ZEND_BEGIN_ARG_WITH_RETURN_OBJ_INFO_EX(arginfo_class_ReflectionEnum_getBackingType, 0, 0, ReflectionNamedType, 1)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionEnumUnitCase___construct arginfo_class_ReflectionClassConstant___construct

ZEND_BEGIN_ARG_WITH_RETURN_OBJ_INFO_EX(arginfo_class_ReflectionEnumUnitCase_getEnum, 0, 0, ReflectionEnum, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_OBJ_INFO_EX(arginfo_class_ReflectionEnumUnitCase_getValue, 0, 0, UnitEnum, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionEnumBackedCase___construct arginfo_class_ReflectionClassConstant___construct

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_MASK_EX(arginfo_class_ReflectionEnumBackedCase_getBackingValue,
                                        0,
                                        0,
                                        MAY_BE_LONG | MAY_BE_STRING)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_ReflectionFiber___construct, 0, 0, 1)
ZEND_ARG_OBJ_INFO(0, fiber, Fiber, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_OBJ_INFO_EX(arginfo_class_ReflectionFiber_getFiber, 0, 0, Fiber, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionFiber_getExecutingFile, 0, 0, IS_STRING, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionFiber_getExecutingLine, 0, 0, IS_LONG, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionFiber_getCallable, 0, 0, IS_CALLABLE, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionFiber_getTrace, 0, 0, IS_ARRAY, 0)
ZEND_ARG_TYPE_INFO_WITH_DEFAULT_VALUE(0, options, IS_LONG, 0, "DEBUG_BACKTRACE_PROVIDE_OBJECT")
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionConstant___construct arginfo_class_ReflectionExtension___construct

#define arginfo_class_ReflectionConstant_getName arginfo_class_ReflectionFunction___toString

#define arginfo_class_ReflectionConstant_getNamespaceName arginfo_class_ReflectionFunction___toString

#define arginfo_class_ReflectionConstant_getShortName arginfo_class_ReflectionFunction___toString

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_class_ReflectionConstant_getValue, 0, 0, IS_MIXED, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_ReflectionConstant_isDeprecated arginfo_class_ReflectionFunctionAbstract_hasTentativeReturnType

#define arginfo_class_ReflectionConstant___toString arginfo_class_ReflectionFunction___toString

ZEND_METHOD(Reflection, getModifierNames);
ZEND_METHOD(ReflectionClass, __clone);
ZEND_METHOD(ReflectionFunctionAbstract, inNamespace);
ZEND_METHOD(ReflectionFunctionAbstract, isClosure);
ZEND_METHOD(ReflectionFunctionAbstract, isDeprecated);
ZEND_METHOD(ReflectionFunctionAbstract, isInternal);
ZEND_METHOD(ReflectionFunctionAbstract, isUserDefined);
ZEND_METHOD(ReflectionFunctionAbstract, isGenerator);
ZEND_METHOD(ReflectionFunctionAbstract, isVariadic);
ZEND_METHOD(ReflectionFunctionAbstract, isStatic);
ZEND_METHOD(ReflectionFunctionAbstract, getClosureThis);
ZEND_METHOD(ReflectionFunctionAbstract, getClosureScopeClass);
ZEND_METHOD(ReflectionFunctionAbstract, getClosureCalledClass);
ZEND_METHOD(ReflectionFunctionAbstract, getClosureUsedVariables);
ZEND_METHOD(ReflectionFunctionAbstract, getDocComment);
ZEND_METHOD(ReflectionFunctionAbstract, getEndLine);
ZEND_METHOD(ReflectionFunctionAbstract, getExtension);
ZEND_METHOD(ReflectionFunctionAbstract, getExtensionName);
ZEND_METHOD(ReflectionFunctionAbstract, getFileName);
ZEND_METHOD(ReflectionFunctionAbstract, getName);
ZEND_METHOD(ReflectionFunctionAbstract, getNamespaceName);
ZEND_METHOD(ReflectionFunctionAbstract, getNumberOfParameters);
ZEND_METHOD(ReflectionFunctionAbstract, getNumberOfRequiredParameters);
ZEND_METHOD(ReflectionFunctionAbstract, getParameters);
ZEND_METHOD(ReflectionFunctionAbstract, getShortName);
ZEND_METHOD(ReflectionFunctionAbstract, getStartLine);
ZEND_METHOD(ReflectionFunctionAbstract, getStaticVariables);
ZEND_METHOD(ReflectionFunctionAbstract, returnsReference);
ZEND_METHOD(ReflectionFunctionAbstract, hasReturnType);
ZEND_METHOD(ReflectionFunctionAbstract, getReturnType);
ZEND_METHOD(ReflectionFunctionAbstract, hasTentativeReturnType);
ZEND_METHOD(ReflectionFunctionAbstract, getTentativeReturnType);
ZEND_METHOD(ReflectionFunctionAbstract, getAttributes);
ZEND_METHOD(ReflectionFunction, __construct);
ZEND_METHOD(ReflectionFunction, __toString);
ZEND_METHOD(ReflectionFunction, isAnonymous);
ZEND_METHOD(ReflectionFunction, isDisabled);
ZEND_METHOD(ReflectionFunction, invoke);
ZEND_METHOD(ReflectionFunction, invokeArgs);
ZEND_METHOD(ReflectionFunction, getClosure);
ZEND_METHOD(ReflectionGenerator, __construct);
ZEND_METHOD(ReflectionGenerator, getExecutingLine);
ZEND_METHOD(ReflectionGenerator, getExecutingFile);
ZEND_METHOD(ReflectionGenerator, getTrace);
ZEND_METHOD(ReflectionGenerator, getFunction);
ZEND_METHOD(ReflectionGenerator, getThis);
ZEND_METHOD(ReflectionGenerator, getExecutingGenerator);
ZEND_METHOD(ReflectionGenerator, isClosed);
ZEND_METHOD(ReflectionMethod, __construct);
ZEND_METHOD(ReflectionMethod, createFromMethodName);
ZEND_METHOD(ReflectionMethod, __toString);
ZEND_METHOD(ReflectionMethod, isPublic);
ZEND_METHOD(ReflectionMethod, isPrivate);
ZEND_METHOD(ReflectionMethod, isProtected);
ZEND_METHOD(ReflectionMethod, isAbstract);
ZEND_METHOD(ReflectionMethod, isFinal);
ZEND_METHOD(ReflectionMethod, isConstructor);
ZEND_METHOD(ReflectionMethod, isDestructor);
ZEND_METHOD(ReflectionMethod, getClosure);
ZEND_METHOD(ReflectionMethod, getModifiers);
ZEND_METHOD(ReflectionMethod, invoke);
ZEND_METHOD(ReflectionMethod, invokeArgs);
ZEND_METHOD(ReflectionMethod, getDeclaringClass);
ZEND_METHOD(ReflectionMethod, getPrototype);
ZEND_METHOD(ReflectionMethod, hasPrototype);
ZEND_METHOD(ReflectionMethod, setAccessible);
ZEND_METHOD(ReflectionClass, __construct);
ZEND_METHOD(ReflectionClass, __toString);
ZEND_METHOD(ReflectionClass, getName);
ZEND_METHOD(ReflectionClass, isInternal);
ZEND_METHOD(ReflectionClass, isUserDefined);
ZEND_METHOD(ReflectionClass, isAnonymous);
ZEND_METHOD(ReflectionClass, isInstantiable);
ZEND_METHOD(ReflectionClass, isCloneable);
ZEND_METHOD(ReflectionClass, getFileName);
ZEND_METHOD(ReflectionClass, getStartLine);
ZEND_METHOD(ReflectionClass, getEndLine);
ZEND_METHOD(ReflectionClass, getDocComment);
ZEND_METHOD(ReflectionClass, getConstructor);
ZEND_METHOD(ReflectionClass, hasMethod);
ZEND_METHOD(ReflectionClass, getMethod);
ZEND_METHOD(ReflectionClass, getMethods);
ZEND_METHOD(ReflectionClass, hasProperty);
ZEND_METHOD(ReflectionClass, getProperty);
ZEND_METHOD(ReflectionClass, getProperties);
ZEND_METHOD(ReflectionClass, hasConstant);
ZEND_METHOD(ReflectionClass, getConstants);
ZEND_METHOD(ReflectionClass, getReflectionConstants);
ZEND_METHOD(ReflectionClass, getConstant);
ZEND_METHOD(ReflectionClass, getReflectionConstant);
ZEND_METHOD(ReflectionClass, getInterfaces);
ZEND_METHOD(ReflectionClass, getInterfaceNames);
ZEND_METHOD(ReflectionClass, isInterface);
ZEND_METHOD(ReflectionClass, getTraits);
ZEND_METHOD(ReflectionClass, getTraitNames);
ZEND_METHOD(ReflectionClass, getTraitAliases);
ZEND_METHOD(ReflectionClass, isTrait);
ZEND_METHOD(ReflectionClass, isEnum);
ZEND_METHOD(ReflectionClass, isAbstract);
ZEND_METHOD(ReflectionClass, isFinal);
ZEND_METHOD(ReflectionClass, isReadOnly);
ZEND_METHOD(ReflectionClass, getModifiers);
ZEND_METHOD(ReflectionClass, isInstance);
ZEND_METHOD(ReflectionClass, newInstance);
ZEND_METHOD(ReflectionClass, newInstanceWithoutConstructor);
ZEND_METHOD(ReflectionClass, newInstanceArgs);
ZEND_METHOD(ReflectionClass, newLazyGhost);
ZEND_METHOD(ReflectionClass, newLazyProxy);
ZEND_METHOD(ReflectionClass, resetAsLazyGhost);
ZEND_METHOD(ReflectionClass, resetAsLazyProxy);
ZEND_METHOD(ReflectionClass, initializeLazyObject);
ZEND_METHOD(ReflectionClass, isUninitializedLazyObject);
ZEND_METHOD(ReflectionClass, markLazyObjectAsInitialized);
ZEND_METHOD(ReflectionClass, getLazyInitializer);
ZEND_METHOD(ReflectionClass, getParentClass);
ZEND_METHOD(ReflectionClass, isSubclassOf);
ZEND_METHOD(ReflectionClass, getStaticProperties);
ZEND_METHOD(ReflectionClass, getStaticPropertyValue);
ZEND_METHOD(ReflectionClass, setStaticPropertyValue);
ZEND_METHOD(ReflectionClass, getDefaultProperties);
ZEND_METHOD(ReflectionClass, isIterable);
ZEND_METHOD(ReflectionClass, implementsInterface);
ZEND_METHOD(ReflectionClass, getExtension);
ZEND_METHOD(ReflectionClass, getExtensionName);
ZEND_METHOD(ReflectionClass, inNamespace);
ZEND_METHOD(ReflectionClass, getNamespaceName);
ZEND_METHOD(ReflectionClass, getShortName);
ZEND_METHOD(ReflectionClass, getAttributes);
ZEND_METHOD(ReflectionObject, __construct);
ZEND_METHOD(ReflectionProperty, __construct);
ZEND_METHOD(ReflectionProperty, __toString);
ZEND_METHOD(ReflectionProperty, getName);
ZEND_METHOD(ReflectionProperty, getValue);
ZEND_METHOD(ReflectionProperty, setValue);
ZEND_METHOD(ReflectionProperty, getRawValue);
ZEND_METHOD(ReflectionProperty, setRawValue);
ZEND_METHOD(ReflectionProperty, setRawValueWithoutLazyInitialization);
ZEND_METHOD(ReflectionProperty, skipLazyInitialization);
ZEND_METHOD(ReflectionProperty, isLazy);
ZEND_METHOD(ReflectionProperty, isInitialized);
ZEND_METHOD(ReflectionProperty, isPublic);
ZEND_METHOD(ReflectionProperty, isPrivate);
ZEND_METHOD(ReflectionProperty, isProtected);
ZEND_METHOD(ReflectionProperty, isPrivateSet);
ZEND_METHOD(ReflectionProperty, isProtectedSet);
ZEND_METHOD(ReflectionProperty, isStatic);
ZEND_METHOD(ReflectionProperty, isReadOnly);
ZEND_METHOD(ReflectionProperty, isDefault);
ZEND_METHOD(ReflectionProperty, isDynamic);
ZEND_METHOD(ReflectionProperty, isAbstract);
ZEND_METHOD(ReflectionProperty, isVirtual);
ZEND_METHOD(ReflectionProperty, isPromoted);
ZEND_METHOD(ReflectionProperty, getModifiers);
ZEND_METHOD(ReflectionProperty, getDeclaringClass);
ZEND_METHOD(ReflectionProperty, getDocComment);
ZEND_METHOD(ReflectionProperty, setAccessible);
ZEND_METHOD(ReflectionProperty, getType);
ZEND_METHOD(ReflectionProperty, getSettableType);
ZEND_METHOD(ReflectionProperty, hasType);
ZEND_METHOD(ReflectionProperty, hasDefaultValue);
ZEND_METHOD(ReflectionProperty, getDefaultValue);
ZEND_METHOD(ReflectionProperty, getAttributes);
ZEND_METHOD(ReflectionProperty, hasHooks);
ZEND_METHOD(ReflectionProperty, getHooks);
ZEND_METHOD(ReflectionProperty, hasHook);
ZEND_METHOD(ReflectionProperty, getHook);
ZEND_METHOD(ReflectionProperty, isFinal);
ZEND_METHOD(ReflectionClassConstant, __construct);
ZEND_METHOD(ReflectionClassConstant, __toString);
ZEND_METHOD(ReflectionClassConstant, getName);
ZEND_METHOD(ReflectionClassConstant, getValue);
ZEND_METHOD(ReflectionClassConstant, isPublic);
ZEND_METHOD(ReflectionClassConstant, isPrivate);
ZEND_METHOD(ReflectionClassConstant, isProtected);
ZEND_METHOD(ReflectionClassConstant, isFinal);
ZEND_METHOD(ReflectionClassConstant, getModifiers);
ZEND_METHOD(ReflectionClassConstant, getDeclaringClass);
ZEND_METHOD(ReflectionClassConstant, getDocComment);
ZEND_METHOD(ReflectionClassConstant, getAttributes);
ZEND_METHOD(ReflectionClassConstant, isEnumCase);
ZEND_METHOD(ReflectionClassConstant, isDeprecated);
ZEND_METHOD(ReflectionClassConstant, hasType);
ZEND_METHOD(ReflectionClassConstant, getType);
ZEND_METHOD(ReflectionParameter, __construct);
ZEND_METHOD(ReflectionParameter, __toString);
ZEND_METHOD(ReflectionParameter, getName);
ZEND_METHOD(ReflectionParameter, isPassedByReference);
ZEND_METHOD(ReflectionParameter, canBePassedByValue);
ZEND_METHOD(ReflectionParameter, getDeclaringFunction);
ZEND_METHOD(ReflectionParameter, getDeclaringClass);
ZEND_METHOD(ReflectionParameter, getClass);
ZEND_METHOD(ReflectionParameter, hasType);
ZEND_METHOD(ReflectionParameter, getType);
ZEND_METHOD(ReflectionParameter, isArray);
ZEND_METHOD(ReflectionParameter, isCallable);
ZEND_METHOD(ReflectionParameter, allowsNull);
ZEND_METHOD(ReflectionParameter, getPosition);
ZEND_METHOD(ReflectionParameter, isOptional);
ZEND_METHOD(ReflectionParameter, isDefaultValueAvailable);
ZEND_METHOD(ReflectionParameter, getDefaultValue);
ZEND_METHOD(ReflectionParameter, isDefaultValueConstant);
ZEND_METHOD(ReflectionParameter, getDefaultValueConstantName);
ZEND_METHOD(ReflectionParameter, isVariadic);
ZEND_METHOD(ReflectionParameter, isPromoted);
ZEND_METHOD(ReflectionParameter, getAttributes);
ZEND_METHOD(ReflectionType, allowsNull);
ZEND_METHOD(ReflectionType, __toString);
ZEND_METHOD(ReflectionNamedType, getName);
ZEND_METHOD(ReflectionNamedType, isBuiltin);
ZEND_METHOD(ReflectionUnionType, getTypes);
ZEND_METHOD(ReflectionIntersectionType, getTypes);
ZEND_METHOD(ReflectionExtension, __construct);
ZEND_METHOD(ReflectionExtension, __toString);
ZEND_METHOD(ReflectionExtension, getName);
ZEND_METHOD(ReflectionExtension, getVersion);
ZEND_METHOD(ReflectionExtension, getFunctions);
ZEND_METHOD(ReflectionExtension, getConstants);
ZEND_METHOD(ReflectionExtension, getINIEntries);
ZEND_METHOD(ReflectionExtension, getClasses);
ZEND_METHOD(ReflectionExtension, getClassNames);
ZEND_METHOD(ReflectionExtension, getDependencies);
ZEND_METHOD(ReflectionExtension, info);
ZEND_METHOD(ReflectionExtension, isPersistent);
ZEND_METHOD(ReflectionExtension, isTemporary);
ZEND_METHOD(ReflectionZendExtension, __construct);
ZEND_METHOD(ReflectionZendExtension, __toString);
ZEND_METHOD(ReflectionZendExtension, getName);
ZEND_METHOD(ReflectionZendExtension, getVersion);
ZEND_METHOD(ReflectionZendExtension, getAuthor);
ZEND_METHOD(ReflectionZendExtension, getURL);
ZEND_METHOD(ReflectionZendExtension, getCopyright);
ZEND_METHOD(ReflectionReference, fromArrayElement);
ZEND_METHOD(ReflectionReference, getId);
ZEND_METHOD(ReflectionReference, __construct);
ZEND_METHOD(ReflectionAttribute, getName);
ZEND_METHOD(ReflectionAttribute, getTarget);
ZEND_METHOD(ReflectionAttribute, isRepeated);
ZEND_METHOD(ReflectionAttribute, getArguments);
ZEND_METHOD(ReflectionAttribute, newInstance);
ZEND_METHOD(ReflectionAttribute, __toString);
ZEND_METHOD(ReflectionAttribute, __clone);
ZEND_METHOD(ReflectionAttribute, __construct);
ZEND_METHOD(ReflectionEnum, __construct);
ZEND_METHOD(ReflectionEnum, hasCase);
ZEND_METHOD(ReflectionEnum, getCase);
ZEND_METHOD(ReflectionEnum, getCases);
ZEND_METHOD(ReflectionEnum, isBacked);
ZEND_METHOD(ReflectionEnum, getBackingType);
ZEND_METHOD(ReflectionEnumUnitCase, __construct);
ZEND_METHOD(ReflectionEnumUnitCase, getEnum);
ZEND_METHOD(ReflectionEnumBackedCase, __construct);
ZEND_METHOD(ReflectionEnumBackedCase, getBackingValue);
ZEND_METHOD(ReflectionFiber, __construct);
ZEND_METHOD(ReflectionFiber, getFiber);
ZEND_METHOD(ReflectionFiber, getExecutingFile);
ZEND_METHOD(ReflectionFiber, getExecutingLine);
ZEND_METHOD(ReflectionFiber, getCallable);
ZEND_METHOD(ReflectionFiber, getTrace);
ZEND_METHOD(ReflectionConstant, __construct);
ZEND_METHOD(ReflectionConstant, getName);
ZEND_METHOD(ReflectionConstant, getNamespaceName);
ZEND_METHOD(ReflectionConstant, getShortName);
ZEND_METHOD(ReflectionConstant, getValue);
ZEND_METHOD(ReflectionConstant, isDeprecated);
ZEND_METHOD(ReflectionConstant, __toString);

static const zend_function_entry class_Reflection_methods[] = {
    ZEND_ME(Reflection, getModifierNames, arginfo_class_Reflection_getModifierNames, ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
        ZEND_FE_END};

static const zend_function_entry class_ReflectionFunctionAbstract_methods[] = {
    ZEND_RAW_FENTRY("__clone",
                    zim_ReflectionClass___clone,
                    arginfo_class_ReflectionFunctionAbstract___clone,
                    ZEND_ACC_PRIVATE,
                    NULL,
                    NULL) ZEND_ME(ReflectionFunctionAbstract,
                                  inNamespace,
                                  arginfo_class_ReflectionFunctionAbstract_inNamespace,
                                  ZEND_ACC_PUBLIC) ZEND_ME(ReflectionFunctionAbstract,
                                                           isClosure,
                                                           arginfo_class_ReflectionFunctionAbstract_isClosure,
                                                           ZEND_ACC_PUBLIC)
        ZEND_ME(
            ReflectionFunctionAbstract,
            isDeprecated,
            arginfo_class_ReflectionFunctionAbstract_isDeprecated,
            ZEND_ACC_PUBLIC) ZEND_ME(ReflectionFunctionAbstract,
                                     isInternal,
                                     arginfo_class_ReflectionFunctionAbstract_isInternal,
                                     ZEND_ACC_PUBLIC) ZEND_ME(ReflectionFunctionAbstract,
                                                              isUserDefined,
                                                              arginfo_class_ReflectionFunctionAbstract_isUserDefined,
                                                              ZEND_ACC_PUBLIC)
            ZEND_ME(ReflectionFunctionAbstract,
                    isGenerator,
                    arginfo_class_ReflectionFunctionAbstract_isGenerator,
                    ZEND_ACC_PUBLIC) ZEND_ME(ReflectionFunctionAbstract,
                                             isVariadic,
                                             arginfo_class_ReflectionFunctionAbstract_isVariadic,
                                             ZEND_ACC_PUBLIC) ZEND_ME(ReflectionFunctionAbstract,
                                                                      isStatic,
                                                                      arginfo_class_ReflectionFunctionAbstract_isStatic,
                                                                      ZEND_ACC_PUBLIC)
                ZEND_ME(ReflectionFunctionAbstract,
                        getClosureThis,
                        arginfo_class_ReflectionFunctionAbstract_getClosureThis,
                        ZEND_ACC_PUBLIC) ZEND_ME(ReflectionFunctionAbstract,
                                                 getClosureScopeClass,
                                                 arginfo_class_ReflectionFunctionAbstract_getClosureScopeClass,
                                                 ZEND_ACC_PUBLIC)
                    ZEND_ME(ReflectionFunctionAbstract,
                            getClosureCalledClass,
                            arginfo_class_ReflectionFunctionAbstract_getClosureCalledClass,
                            ZEND_ACC_PUBLIC) ZEND_ME(ReflectionFunctionAbstract,
                                                     getClosureUsedVariables,
                                                     arginfo_class_ReflectionFunctionAbstract_getClosureUsedVariables,
                                                     ZEND_ACC_PUBLIC)
                        ZEND_ME(ReflectionFunctionAbstract,
                                getDocComment,
                                arginfo_class_ReflectionFunctionAbstract_getDocComment,
                                ZEND_ACC_PUBLIC) ZEND_ME(ReflectionFunctionAbstract,
                                                         getEndLine,
                                                         arginfo_class_ReflectionFunctionAbstract_getEndLine,
                                                         ZEND_ACC_PUBLIC)
                            ZEND_ME(ReflectionFunctionAbstract,
                                    getExtension,
                                    arginfo_class_ReflectionFunctionAbstract_getExtension,
                                    ZEND_ACC_PUBLIC) ZEND_ME(ReflectionFunctionAbstract,
                                                             getExtensionName,
                                                             arginfo_class_ReflectionFunctionAbstract_getExtensionName,
                                                             ZEND_ACC_PUBLIC)
                                ZEND_ME(ReflectionFunctionAbstract,
                                        getFileName,
                                        arginfo_class_ReflectionFunctionAbstract_getFileName,
                                        ZEND_ACC_PUBLIC) ZEND_ME(ReflectionFunctionAbstract,
                                                                 getName,
                                                                 arginfo_class_ReflectionFunctionAbstract_getName,
                                                                 ZEND_ACC_PUBLIC)
                                    ZEND_ME(
                                        ReflectionFunctionAbstract,
                                        getNamespaceName,
                                        arginfo_class_ReflectionFunctionAbstract_getNamespaceName,
                                        ZEND_ACC_PUBLIC) ZEND_ME(ReflectionFunctionAbstract,
                                                                 getNumberOfParameters,
                                                                 arginfo_class_ReflectionFunctionAbstract_getNumberOfParameters,
                                                                 ZEND_ACC_PUBLIC)
                                        ZEND_ME(
                                            ReflectionFunctionAbstract,
                                            getNumberOfRequiredParameters,
                                            arginfo_class_ReflectionFunctionAbstract_getNumberOfRequiredParameters,
                                            ZEND_ACC_PUBLIC) ZEND_ME(ReflectionFunctionAbstract,
                                                                     getParameters,
                                                                     arginfo_class_ReflectionFunctionAbstract_getParameters,
                                                                     ZEND_ACC_PUBLIC)
                                            ZEND_ME(
                                                ReflectionFunctionAbstract,
                                                getShortName,
                                                arginfo_class_ReflectionFunctionAbstract_getShortName,
                                                ZEND_ACC_PUBLIC) ZEND_ME(ReflectionFunctionAbstract,
                                                                         getStartLine,
                                                                         arginfo_class_ReflectionFunctionAbstract_getStartLine,
                                                                         ZEND_ACC_PUBLIC)
                                                ZEND_ME(
                                                    ReflectionFunctionAbstract,
                                                    getStaticVariables,
                                                    arginfo_class_ReflectionFunctionAbstract_getStaticVariables,
                                                    ZEND_ACC_PUBLIC)
                                                    ZEND_ME(
                                                        ReflectionFunctionAbstract,
                                                        returnsReference,
                                                        arginfo_class_ReflectionFunctionAbstract_returnsReference,
                                                        ZEND_ACC_PUBLIC)
                                                        ZEND_ME(
                                                            ReflectionFunctionAbstract,
                                                            hasReturnType,
                                                            arginfo_class_ReflectionFunctionAbstract_hasReturnType,
                                                            ZEND_ACC_PUBLIC)
                                                            ZEND_ME(
                                                                ReflectionFunctionAbstract,
                                                                getReturnType,
                                                                arginfo_class_ReflectionFunctionAbstract_getReturnType,
                                                                ZEND_ACC_PUBLIC)
                                                                ZEND_ME(
                                                                    ReflectionFunctionAbstract,
                                                                    hasTentativeReturnType,
                                                                    arginfo_class_ReflectionFunctionAbstract_hasTentativeReturnType,
                                                                    ZEND_ACC_PUBLIC)
                                                                    ZEND_ME(
                                                                        ReflectionFunctionAbstract,
                                                                        getTentativeReturnType,
                                                                        arginfo_class_ReflectionFunctionAbstract_getTentativeReturnType,
                                                                        ZEND_ACC_PUBLIC)
                                                                        ZEND_ME(
                                                                            ReflectionFunctionAbstract,
                                                                            getAttributes,
                                                                            arginfo_class_ReflectionFunctionAbstract_getAttributes,
                                                                            ZEND_ACC_PUBLIC) ZEND_FE_END};

static const zend_function_entry class_ReflectionFunction_methods[] = {
    ZEND_ME(ReflectionFunction, __construct, arginfo_class_ReflectionFunction___construct, ZEND_ACC_PUBLIC) ZEND_ME(
        ReflectionFunction, __toString, arginfo_class_ReflectionFunction___toString, ZEND_ACC_PUBLIC)
        ZEND_ME(ReflectionFunction, isAnonymous, arginfo_class_ReflectionFunction_isAnonymous, ZEND_ACC_PUBLIC) ZEND_ME(
            ReflectionFunction,
            isDisabled,
            arginfo_class_ReflectionFunction_isDisabled,
            ZEND_ACC_PUBLIC | ZEND_ACC_DEPRECATED)
            ZEND_ME(ReflectionFunction, invoke, arginfo_class_ReflectionFunction_invoke, ZEND_ACC_PUBLIC) ZEND_ME(
                ReflectionFunction, invokeArgs, arginfo_class_ReflectionFunction_invokeArgs, ZEND_ACC_PUBLIC)
                ZEND_ME(ReflectionFunction, getClosure, arginfo_class_ReflectionFunction_getClosure, ZEND_ACC_PUBLIC)
                    ZEND_FE_END};

static const zend_function_entry class_ReflectionGenerator_methods[] = {
    ZEND_ME(ReflectionGenerator, __construct, arginfo_class_ReflectionGenerator___construct, ZEND_ACC_PUBLIC) ZEND_ME(
        ReflectionGenerator, getExecutingLine, arginfo_class_ReflectionGenerator_getExecutingLine, ZEND_ACC_PUBLIC)
        ZEND_ME(
            ReflectionGenerator, getExecutingFile, arginfo_class_ReflectionGenerator_getExecutingFile, ZEND_ACC_PUBLIC)
            ZEND_ME(ReflectionGenerator, getTrace, arginfo_class_ReflectionGenerator_getTrace, ZEND_ACC_PUBLIC) ZEND_ME(
                ReflectionGenerator, getFunction, arginfo_class_ReflectionGenerator_getFunction, ZEND_ACC_PUBLIC)
                ZEND_ME(ReflectionGenerator, getThis, arginfo_class_ReflectionGenerator_getThis, ZEND_ACC_PUBLIC)
                    ZEND_ME(ReflectionGenerator,
                            getExecutingGenerator,
                            arginfo_class_ReflectionGenerator_getExecutingGenerator,
                            ZEND_ACC_PUBLIC)
                        ZEND_ME(
                            ReflectionGenerator, isClosed, arginfo_class_ReflectionGenerator_isClosed, ZEND_ACC_PUBLIC)
                            ZEND_FE_END};

static const zend_function_entry class_ReflectionMethod_methods[] = {
    ZEND_ME(ReflectionMethod, __construct, arginfo_class_ReflectionMethod___construct, ZEND_ACC_PUBLIC) ZEND_ME(
        ReflectionMethod,
        createFromMethodName,
        arginfo_class_ReflectionMethod_createFromMethodName,
        ZEND_ACC_PUBLIC | ZEND_ACC_STATIC) ZEND_ME(ReflectionMethod,
                                                   __toString,
                                                   arginfo_class_ReflectionMethod___toString,
                                                   ZEND_ACC_PUBLIC)
        ZEND_ME(ReflectionMethod, isPublic, arginfo_class_ReflectionMethod_isPublic, ZEND_ACC_PUBLIC) ZEND_ME(
            ReflectionMethod, isPrivate, arginfo_class_ReflectionMethod_isPrivate, ZEND_ACC_PUBLIC)
            ZEND_ME(ReflectionMethod, isProtected, arginfo_class_ReflectionMethod_isProtected, ZEND_ACC_PUBLIC) ZEND_ME(
                ReflectionMethod, isAbstract, arginfo_class_ReflectionMethod_isAbstract, ZEND_ACC_PUBLIC)
                ZEND_ME(ReflectionMethod, isFinal, arginfo_class_ReflectionMethod_isFinal, ZEND_ACC_PUBLIC) ZEND_ME(
                    ReflectionMethod, isConstructor, arginfo_class_ReflectionMethod_isConstructor, ZEND_ACC_PUBLIC)
                    ZEND_ME(
                        ReflectionMethod, isDestructor, arginfo_class_ReflectionMethod_isDestructor, ZEND_ACC_PUBLIC)
                        ZEND_ME(ReflectionMethod,
                                getClosure,
                                arginfo_class_ReflectionMethod_getClosure,
                                ZEND_ACC_PUBLIC) ZEND_ME(ReflectionMethod,
                                                         getModifiers,
                                                         arginfo_class_ReflectionMethod_getModifiers,
                                                         ZEND_ACC_PUBLIC)
                            ZEND_ME(ReflectionMethod, invoke, arginfo_class_ReflectionMethod_invoke, ZEND_ACC_PUBLIC)
                                ZEND_ME(ReflectionMethod,
                                        invokeArgs,
                                        arginfo_class_ReflectionMethod_invokeArgs,
                                        ZEND_ACC_PUBLIC) ZEND_ME(ReflectionMethod,
                                                                 getDeclaringClass,
                                                                 arginfo_class_ReflectionMethod_getDeclaringClass,
                                                                 ZEND_ACC_PUBLIC)
                                    ZEND_ME(ReflectionMethod,
                                            getPrototype,
                                            arginfo_class_ReflectionMethod_getPrototype,
                                            ZEND_ACC_PUBLIC) ZEND_ME(ReflectionMethod,
                                                                     hasPrototype,
                                                                     arginfo_class_ReflectionMethod_hasPrototype,
                                                                     ZEND_ACC_PUBLIC)
                                        ZEND_ME(ReflectionMethod,
                                                setAccessible,
                                                arginfo_class_ReflectionMethod_setAccessible,
                                                ZEND_ACC_PUBLIC) ZEND_FE_END};

static const zend_function_entry class_ReflectionClass_methods
    [] = {ZEND_ME(ReflectionClass, __clone, arginfo_class_ReflectionClass___clone, ZEND_ACC_PRIVATE) ZEND_ME(
        ReflectionClass,
        __construct,
        arginfo_class_ReflectionClass___construct,
        ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass, __toString, arginfo_class_ReflectionClass___toString, ZEND_ACC_PUBLIC)
              ZEND_ME(ReflectionClass, getName, arginfo_class_ReflectionClass_getName, ZEND_ACC_PUBLIC) ZEND_ME(
                  ReflectionClass,
                  isInternal,
                  arginfo_class_ReflectionClass_isInternal,
                  ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass,
                                           isUserDefined,
                                           arginfo_class_ReflectionClass_isUserDefined,
                                           ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass,
                                                                    isAnonymous,
                                                                    arginfo_class_ReflectionClass_isAnonymous,
                                                                    ZEND_ACC_PUBLIC)
                  ZEND_ME(
                      ReflectionClass,
                      isInstantiable,
                      arginfo_class_ReflectionClass_isInstantiable,
                      ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass,
                                               isCloneable,
                                               arginfo_class_ReflectionClass_isCloneable,
                                               ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass,
                                                                        getFileName,
                                                                        arginfo_class_ReflectionClass_getFileName,
                                                                        ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass,
                                                                                                 getStartLine,
                                                                                                 arginfo_class_ReflectionClass_getStartLine,
                                                                                                 ZEND_ACC_PUBLIC)
                      ZEND_ME(ReflectionClass, getEndLine, arginfo_class_ReflectionClass_getEndLine, ZEND_ACC_PUBLIC) ZEND_ME(
                          ReflectionClass,
                          getDocComment,
                          arginfo_class_ReflectionClass_getDocComment,
                          ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass, getConstructor, arginfo_class_ReflectionClass_getConstructor, ZEND_ACC_PUBLIC)
                          ZEND_ME(ReflectionClass, hasMethod, arginfo_class_ReflectionClass_hasMethod, ZEND_ACC_PUBLIC) ZEND_ME(
                              ReflectionClass,
                              getMethod,
                              arginfo_class_ReflectionClass_getMethod,
                              ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass, getMethods, arginfo_class_ReflectionClass_getMethods, ZEND_ACC_PUBLIC)
                              ZEND_ME(ReflectionClass, hasProperty, arginfo_class_ReflectionClass_hasProperty, ZEND_ACC_PUBLIC) ZEND_ME(
                                  ReflectionClass,
                                  getProperty,
                                  arginfo_class_ReflectionClass_getProperty,
                                  ZEND_ACC_PUBLIC)
                                  ZEND_ME(ReflectionClass, getProperties, arginfo_class_ReflectionClass_getProperties, ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass, hasConstant, arginfo_class_ReflectionClass_hasConstant, ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass, getConstants, arginfo_class_ReflectionClass_getConstants, ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass, getReflectionConstants, arginfo_class_ReflectionClass_getReflectionConstants, ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass, getConstant, arginfo_class_ReflectionClass_getConstant, ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass, getReflectionConstant, arginfo_class_ReflectionClass_getReflectionConstant, ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      getInterfaces,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      arginfo_class_ReflectionClass_getInterfaces,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass, getInterfaceNames, arginfo_class_ReflectionClass_getInterfaceNames, ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             isInterface,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             arginfo_class_ReflectionClass_isInterface,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass, getTraits, arginfo_class_ReflectionClass_getTraits, ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    getTraitNames,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    arginfo_class_ReflectionClass_getTraitNames,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass, getTraitAliases, arginfo_class_ReflectionClass_getTraitAliases, ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       isTrait,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       arginfo_class_ReflectionClass_isTrait,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass, isEnum, arginfo_class_ReflectionClass_isEnum, ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        isAbstract,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        arginfo_class_ReflectionClass_isAbstract,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 isFinal,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 arginfo_class_ReflectionClass_isFinal,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 ZEND_ACC_PUBLIC)
                                      ZEND_ME(ReflectionClass, isReadOnly, arginfo_class_ReflectionClass_isReadOnly, ZEND_ACC_PUBLIC) ZEND_ME(
                                          ReflectionClass,
                                          getModifiers,
                                          arginfo_class_ReflectionClass_getModifiers,
                                          ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass, isInstance, arginfo_class_ReflectionClass_isInstance, ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass,
                                                                                                                                                                   newInstance,
                                                                                                                                                                   arginfo_class_ReflectionClass_newInstance,
                                                                                                                                                                   ZEND_ACC_PUBLIC)
                                          ZEND_ME(
                                              ReflectionClass,
                                              newInstanceWithoutConstructor,
                                              arginfo_class_ReflectionClass_newInstanceWithoutConstructor,
                                              ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass, newInstanceArgs, arginfo_class_ReflectionClass_newInstanceArgs, ZEND_ACC_PUBLIC)
                                              ZEND_ME(ReflectionClass, newLazyGhost, arginfo_class_ReflectionClass_newLazyGhost, ZEND_ACC_PUBLIC) ZEND_ME(
                                                  ReflectionClass,
                                                  newLazyProxy,
                                                  arginfo_class_ReflectionClass_newLazyProxy,
                                                  ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass, resetAsLazyGhost, arginfo_class_ReflectionClass_resetAsLazyGhost, ZEND_ACC_PUBLIC)
                                                  ZEND_ME(ReflectionClass, resetAsLazyProxy, arginfo_class_ReflectionClass_resetAsLazyProxy, ZEND_ACC_PUBLIC) ZEND_ME(
                                                      ReflectionClass,
                                                      initializeLazyObject,
                                                      arginfo_class_ReflectionClass_initializeLazyObject,
                                                      ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass, isUninitializedLazyObject, arginfo_class_ReflectionClass_isUninitializedLazyObject, ZEND_ACC_PUBLIC)
                                                      ZEND_ME(
                                                          ReflectionClass,
                                                          markLazyObjectAsInitialized,
                                                          arginfo_class_ReflectionClass_markLazyObjectAsInitialized,
                                                          ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass, getLazyInitializer, arginfo_class_ReflectionClass_getLazyInitializer, ZEND_ACC_PUBLIC)
                                                          ZEND_ME(ReflectionClass, getParentClass, arginfo_class_ReflectionClass_getParentClass, ZEND_ACC_PUBLIC) ZEND_ME(
                                                              ReflectionClass,
                                                              isSubclassOf,
                                                              arginfo_class_ReflectionClass_isSubclassOf,
                                                              ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClass, getStaticProperties, arginfo_class_ReflectionClass_getStaticProperties, ZEND_ACC_PUBLIC)
                                                              ZEND_ME(
                                                                  ReflectionClass,
                                                                  getStaticPropertyValue,
                                                                  arginfo_class_ReflectionClass_getStaticPropertyValue,
                                                                  ZEND_ACC_PUBLIC)
                                                                  ZEND_ME(
                                                                      ReflectionClass,
                                                                      setStaticPropertyValue,
                                                                      arginfo_class_ReflectionClass_setStaticPropertyValue,
                                                                      ZEND_ACC_PUBLIC)
                                                                      ZEND_ME(
                                                                          ReflectionClass,
                                                                          getDefaultProperties,
                                                                          arginfo_class_ReflectionClass_getDefaultProperties,
                                                                          ZEND_ACC_PUBLIC)
                                                                          ZEND_ME(
                                                                              ReflectionClass,
                                                                              isIterable,
                                                                              arginfo_class_ReflectionClass_isIterable,
                                                                              ZEND_ACC_PUBLIC)
                                                                              ZEND_RAW_FENTRY(
                                                                                  "isI"
                                                                                  "ter"
                                                                                  "ate"
                                                                                  "abl"
                                                                                  "e",
                                                                                  zim_ReflectionClass_isIterable,
                                                                                  arginfo_class_ReflectionClass_isIterateable,
                                                                                  ZEND_ACC_PUBLIC,
                                                                                  NULL,
                                                                                  NULL)
                                                                                  ZEND_ME(
                                                                                      ReflectionClass,
                                                                                      implementsInterface,
                                                                                      arginfo_class_ReflectionClass_implementsInterface,
                                                                                      ZEND_ACC_PUBLIC)
                                                                                      ZEND_ME(
                                                                                          ReflectionClass,
                                                                                          getExtension,
                                                                                          arginfo_class_ReflectionClass_getExtension,
                                                                                          ZEND_ACC_PUBLIC)
                                                                                          ZEND_ME(
                                                                                              ReflectionClass,
                                                                                              getExtensionName,
                                                                                              arginfo_class_ReflectionClass_getExtensionName,
                                                                                              ZEND_ACC_PUBLIC)
                                                                                              ZEND_ME(
                                                                                                  ReflectionClass,
                                                                                                  inNamespace,
                                                                                                  arginfo_class_ReflectionClass_inNamespace,
                                                                                                  ZEND_ACC_PUBLIC)
                                                                                                  ZEND_ME(
                                                                                                      ReflectionClass,
                                                                                                      getNamespaceName,
                                                                                                      arginfo_class_ReflectionClass_getNamespaceName,
                                                                                                      ZEND_ACC_PUBLIC)
                                                                                                      ZEND_ME(
                                                                                                          ReflectionClass,
                                                                                                          getShortName,
                                                                                                          arginfo_class_ReflectionClass_getShortName,
                                                                                                          ZEND_ACC_PUBLIC)
                                                                                                          ZEND_ME(
                                                                                                              ReflectionClass,
                                                                                                              getAttributes,
                                                                                                              arginfo_class_ReflectionClass_getAttributes,
                                                                                                              ZEND_ACC_PUBLIC)
                                                                                                              ZEND_FE_END};

static const zend_function_entry class_ReflectionObject_methods[] = {
    ZEND_ME(ReflectionObject, __construct, arginfo_class_ReflectionObject___construct, ZEND_ACC_PUBLIC) ZEND_FE_END};

static const zend_function_entry class_ReflectionProperty_methods[] =
    {ZEND_RAW_FENTRY(
        "__clone",
        zim_ReflectionClass___clone,
        arginfo_class_ReflectionProperty___clone,
        ZEND_ACC_PRIVATE,
        NULL,
        NULL) ZEND_ME(ReflectionProperty,
                      __construct,
                      arginfo_class_ReflectionProperty___construct,
                      ZEND_ACC_PUBLIC) ZEND_ME(ReflectionProperty,
                                               __toString,
                                               arginfo_class_ReflectionProperty___toString,
                                               ZEND_ACC_PUBLIC) ZEND_ME(ReflectionProperty,
                                                                        getName,
                                                                        arginfo_class_ReflectionProperty_getName,
                                                                        ZEND_ACC_PUBLIC)
         ZEND_ME(ReflectionProperty, getValue, arginfo_class_ReflectionProperty_getValue, ZEND_ACC_PUBLIC) ZEND_ME(
             ReflectionProperty,
             setValue,
             arginfo_class_ReflectionProperty_setValue,
             ZEND_ACC_PUBLIC) ZEND_ME(ReflectionProperty,
                                      getRawValue,
                                      arginfo_class_ReflectionProperty_getRawValue,
                                      ZEND_ACC_PUBLIC) ZEND_ME(ReflectionProperty,
                                                               setRawValue,
                                                               arginfo_class_ReflectionProperty_setRawValue,
                                                               ZEND_ACC_PUBLIC)
             ZEND_ME(ReflectionProperty,
                     setRawValueWithoutLazyInitialization,
                     arginfo_class_ReflectionProperty_setRawValueWithoutLazyInitialization,
                     ZEND_ACC_PUBLIC) ZEND_ME(ReflectionProperty,
                                              skipLazyInitialization,
                                              arginfo_class_ReflectionProperty_skipLazyInitialization,
                                              ZEND_ACC_PUBLIC)
                 ZEND_ME(ReflectionProperty, isLazy, arginfo_class_ReflectionProperty_isLazy, ZEND_ACC_PUBLIC) ZEND_ME(
                     ReflectionProperty, isInitialized, arginfo_class_ReflectionProperty_isInitialized, ZEND_ACC_PUBLIC)
                     ZEND_ME(
                         ReflectionProperty,
                         isPublic,
                         arginfo_class_ReflectionProperty_isPublic,
                         ZEND_ACC_PUBLIC) ZEND_ME(ReflectionProperty,
                                                  isPrivate,
                                                  arginfo_class_ReflectionProperty_isPrivate,
                                                  ZEND_ACC_PUBLIC) ZEND_ME(ReflectionProperty,
                                                                           isProtected,
                                                                           arginfo_class_ReflectionProperty_isProtected,
                                                                           ZEND_ACC_PUBLIC)
                         ZEND_ME(
                             ReflectionProperty,
                             isPrivateSet,
                             arginfo_class_ReflectionProperty_isPrivateSet,
                             ZEND_ACC_PUBLIC) ZEND_ME(ReflectionProperty,
                                                      isProtectedSet,
                                                      arginfo_class_ReflectionProperty_isProtectedSet,
                                                      ZEND_ACC_PUBLIC)
                             ZEND_ME(
                                 ReflectionProperty,
                                 isStatic,
                                 arginfo_class_ReflectionProperty_isStatic,
                                 ZEND_ACC_PUBLIC) ZEND_ME(ReflectionProperty,
                                                          isReadOnly,
                                                          arginfo_class_ReflectionProperty_isReadOnly,
                                                          ZEND_ACC_PUBLIC)
                                 ZEND_ME(
                                     ReflectionProperty,
                                     isDefault,
                                     arginfo_class_ReflectionProperty_isDefault,
                                     ZEND_ACC_PUBLIC) ZEND_ME(ReflectionProperty,
                                                              isDynamic,
                                                              arginfo_class_ReflectionProperty_isDynamic,
                                                              ZEND_ACC_PUBLIC)
                                     ZEND_ME(
                                         ReflectionProperty,
                                         isAbstract,
                                         arginfo_class_ReflectionProperty_isAbstract,
                                         ZEND_ACC_PUBLIC) ZEND_ME(ReflectionProperty,
                                                                  isVirtual,
                                                                  arginfo_class_ReflectionProperty_isVirtual,
                                                                  ZEND_ACC_PUBLIC)
                                         ZEND_ME(
                                             ReflectionProperty,
                                             isPromoted,
                                             arginfo_class_ReflectionProperty_isPromoted,
                                             ZEND_ACC_PUBLIC) ZEND_ME(ReflectionProperty,
                                                                      getModifiers,
                                                                      arginfo_class_ReflectionProperty_getModifiers,
                                                                      ZEND_ACC_PUBLIC)
                                             ZEND_ME(
                                                 ReflectionProperty,
                                                 getDeclaringClass,
                                                 arginfo_class_ReflectionProperty_getDeclaringClass,
                                                 ZEND_ACC_PUBLIC) ZEND_ME(ReflectionProperty,
                                                                          getDocComment,
                                                                          arginfo_class_ReflectionProperty_getDocComment,
                                                                          ZEND_ACC_PUBLIC)
                                                 ZEND_ME(
                                                     ReflectionProperty,
                                                     setAccessible,
                                                     arginfo_class_ReflectionProperty_setAccessible,
                                                     ZEND_ACC_PUBLIC) ZEND_ME(ReflectionProperty,
                                                                              getType,
                                                                              arginfo_class_ReflectionProperty_getType,
                                                                              ZEND_ACC_PUBLIC)
                                                     ZEND_ME(
                                                         ReflectionProperty,
                                                         getSettableType,
                                                         arginfo_class_ReflectionProperty_getSettableType,
                                                         ZEND_ACC_PUBLIC) ZEND_ME(ReflectionProperty,
                                                                                  hasType,
                                                                                  arginfo_class_ReflectionProperty_hasType,
                                                                                  ZEND_ACC_PUBLIC)
                                                         ZEND_ME(
                                                             ReflectionProperty,
                                                             hasDefaultValue,
                                                             arginfo_class_ReflectionProperty_hasDefaultValue,
                                                             ZEND_ACC_PUBLIC)
                                                             ZEND_ME(
                                                                 ReflectionProperty,
                                                                 getDefaultValue,
                                                                 arginfo_class_ReflectionProperty_getDefaultValue,
                                                                 ZEND_ACC_PUBLIC)
                                                                 ZEND_ME(
                                                                     ReflectionProperty,
                                                                     getAttributes,
                                                                     arginfo_class_ReflectionProperty_getAttributes,
                                                                     ZEND_ACC_PUBLIC)
                                                                     ZEND_ME(
                                                                         ReflectionProperty,
                                                                         hasHooks,
                                                                         arginfo_class_ReflectionProperty_hasHooks,
                                                                         ZEND_ACC_PUBLIC)
                                                                         ZEND_ME(
                                                                             ReflectionProperty,
                                                                             getHooks,
                                                                             arginfo_class_ReflectionProperty_getHooks,
                                                                             ZEND_ACC_PUBLIC)
                                                                             ZEND_ME(
                                                                                 ReflectionProperty,
                                                                                 hasHook,
                                                                                 arginfo_class_ReflectionProperty_hasHook,
                                                                                 ZEND_ACC_PUBLIC)
                                                                                 ZEND_ME(
                                                                                     ReflectionProperty,
                                                                                     getHook,
                                                                                     arginfo_class_ReflectionProperty_getHook,
                                                                                     ZEND_ACC_PUBLIC)
                                                                                     ZEND_ME(
                                                                                         ReflectionProperty,
                                                                                         isFinal,
                                                                                         arginfo_class_ReflectionProperty_isFinal,
                                                                                         ZEND_ACC_PUBLIC) ZEND_FE_END};

static const zend_function_entry class_ReflectionClassConstant_methods[] = {
    ZEND_RAW_FENTRY("__clone",
                    zim_ReflectionClass___clone,
                    arginfo_class_ReflectionClassConstant___clone,
                    ZEND_ACC_PRIVATE,
                    NULL,
                    NULL) ZEND_ME(ReflectionClassConstant,
                                  __construct,
                                  arginfo_class_ReflectionClassConstant___construct,
                                  ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClassConstant,
                                                           __toString,
                                                           arginfo_class_ReflectionClassConstant___toString,
                                                           ZEND_ACC_PUBLIC)
        ZEND_ME(ReflectionClassConstant, getName, arginfo_class_ReflectionClassConstant_getName, ZEND_ACC_PUBLIC)
            ZEND_ME(ReflectionClassConstant, getValue, arginfo_class_ReflectionClassConstant_getValue, ZEND_ACC_PUBLIC)
                ZEND_ME(
                    ReflectionClassConstant, isPublic, arginfo_class_ReflectionClassConstant_isPublic, ZEND_ACC_PUBLIC)
                    ZEND_ME(ReflectionClassConstant,
                            isPrivate,
                            arginfo_class_ReflectionClassConstant_isPrivate,
                            ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClassConstant,
                                                     isProtected,
                                                     arginfo_class_ReflectionClassConstant_isProtected,
                                                     ZEND_ACC_PUBLIC)
                        ZEND_ME(ReflectionClassConstant,
                                isFinal,
                                arginfo_class_ReflectionClassConstant_isFinal,
                                ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClassConstant,
                                                         getModifiers,
                                                         arginfo_class_ReflectionClassConstant_getModifiers,
                                                         ZEND_ACC_PUBLIC)
                            ZEND_ME(ReflectionClassConstant,
                                    getDeclaringClass,
                                    arginfo_class_ReflectionClassConstant_getDeclaringClass,
                                    ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClassConstant,
                                                             getDocComment,
                                                             arginfo_class_ReflectionClassConstant_getDocComment,
                                                             ZEND_ACC_PUBLIC)
                                ZEND_ME(ReflectionClassConstant,
                                        getAttributes,
                                        arginfo_class_ReflectionClassConstant_getAttributes,
                                        ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClassConstant,
                                                                 isEnumCase,
                                                                 arginfo_class_ReflectionClassConstant_isEnumCase,
                                                                 ZEND_ACC_PUBLIC)
                                    ZEND_ME(ReflectionClassConstant,
                                            isDeprecated,
                                            arginfo_class_ReflectionClassConstant_isDeprecated,
                                            ZEND_ACC_PUBLIC) ZEND_ME(ReflectionClassConstant,
                                                                     hasType,
                                                                     arginfo_class_ReflectionClassConstant_hasType,
                                                                     ZEND_ACC_PUBLIC)
                                        ZEND_ME(ReflectionClassConstant,
                                                getType,
                                                arginfo_class_ReflectionClassConstant_getType,
                                                ZEND_ACC_PUBLIC) ZEND_FE_END};

static const zend_function_entry class_ReflectionParameter_methods[] = {
    ZEND_RAW_FENTRY(
        "__clone",
        zim_ReflectionClass___clone,
        arginfo_class_ReflectionParameter___clone,
        ZEND_ACC_PRIVATE,
        NULL,
        NULL) ZEND_ME(ReflectionParameter, __construct, arginfo_class_ReflectionParameter___construct, ZEND_ACC_PUBLIC)
        ZEND_ME(ReflectionParameter, __toString, arginfo_class_ReflectionParameter___toString, ZEND_ACC_PUBLIC) ZEND_ME(
            ReflectionParameter,
            getName,
            arginfo_class_ReflectionParameter_getName,
            ZEND_ACC_PUBLIC) ZEND_ME(ReflectionParameter,
                                     isPassedByReference,
                                     arginfo_class_ReflectionParameter_isPassedByReference,
                                     ZEND_ACC_PUBLIC) ZEND_ME(ReflectionParameter,
                                                              canBePassedByValue,
                                                              arginfo_class_ReflectionParameter_canBePassedByValue,
                                                              ZEND_ACC_PUBLIC)
            ZEND_ME(ReflectionParameter,
                    getDeclaringFunction,
                    arginfo_class_ReflectionParameter_getDeclaringFunction,
                    ZEND_ACC_PUBLIC) ZEND_ME(ReflectionParameter,
                                             getDeclaringClass,
                                             arginfo_class_ReflectionParameter_getDeclaringClass,
                                             ZEND_ACC_PUBLIC) ZEND_ME(ReflectionParameter,
                                                                      getClass,
                                                                      arginfo_class_ReflectionParameter_getClass,
                                                                      ZEND_ACC_PUBLIC | ZEND_ACC_DEPRECATED)
                ZEND_ME(ReflectionParameter, hasType, arginfo_class_ReflectionParameter_hasType, ZEND_ACC_PUBLIC)
                    ZEND_ME(ReflectionParameter, getType, arginfo_class_ReflectionParameter_getType, ZEND_ACC_PUBLIC)
                        ZEND_ME(ReflectionParameter,
                                isArray,
                                arginfo_class_ReflectionParameter_isArray,
                                ZEND_ACC_PUBLIC |
                                    ZEND_ACC_DEPRECATED) ZEND_ME(ReflectionParameter,
                                                                 isCallable,
                                                                 arginfo_class_ReflectionParameter_isCallable,
                                                                 ZEND_ACC_PUBLIC | ZEND_ACC_DEPRECATED)
                            ZEND_ME(ReflectionParameter,
                                    allowsNull,
                                    arginfo_class_ReflectionParameter_allowsNull,
                                    ZEND_ACC_PUBLIC) ZEND_ME(ReflectionParameter,
                                                             getPosition,
                                                             arginfo_class_ReflectionParameter_getPosition,
                                                             ZEND_ACC_PUBLIC)
                                ZEND_ME(ReflectionParameter,
                                        isOptional,
                                        arginfo_class_ReflectionParameter_isOptional,
                                        ZEND_ACC_PUBLIC)
                                    ZEND_ME(ReflectionParameter,
                                            isDefaultValueAvailable,
                                            arginfo_class_ReflectionParameter_isDefaultValueAvailable,
                                            ZEND_ACC_PUBLIC) ZEND_ME(ReflectionParameter,
                                                                     getDefaultValue,
                                                                     arginfo_class_ReflectionParameter_getDefaultValue,
                                                                     ZEND_ACC_PUBLIC)
                                        ZEND_ME(ReflectionParameter,
                                                isDefaultValueConstant,
                                                arginfo_class_ReflectionParameter_isDefaultValueConstant,
                                                ZEND_ACC_PUBLIC)
                                            ZEND_ME(ReflectionParameter,
                                                    getDefaultValueConstantName,
                                                    arginfo_class_ReflectionParameter_getDefaultValueConstantName,
                                                    ZEND_ACC_PUBLIC)
                                                ZEND_ME(ReflectionParameter,
                                                        isVariadic,
                                                        arginfo_class_ReflectionParameter_isVariadic,
                                                        ZEND_ACC_PUBLIC)
                                                    ZEND_ME(ReflectionParameter,
                                                            isPromoted,
                                                            arginfo_class_ReflectionParameter_isPromoted,
                                                            ZEND_ACC_PUBLIC)
                                                        ZEND_ME(ReflectionParameter,
                                                                getAttributes,
                                                                arginfo_class_ReflectionParameter_getAttributes,
                                                                ZEND_ACC_PUBLIC) ZEND_FE_END};

static const zend_function_entry class_ReflectionType_methods[] = {
    ZEND_RAW_FENTRY(
        "__clone", zim_ReflectionClass___clone, arginfo_class_ReflectionType___clone, ZEND_ACC_PRIVATE, NULL, NULL)
        ZEND_ME(ReflectionType, allowsNull, arginfo_class_ReflectionType_allowsNull, ZEND_ACC_PUBLIC)
            ZEND_ME(ReflectionType, __toString, arginfo_class_ReflectionType___toString, ZEND_ACC_PUBLIC) ZEND_FE_END};

static const zend_function_entry class_ReflectionNamedType_methods[] = {
    ZEND_ME(ReflectionNamedType, getName, arginfo_class_ReflectionNamedType_getName, ZEND_ACC_PUBLIC)
        ZEND_ME(ReflectionNamedType, isBuiltin, arginfo_class_ReflectionNamedType_isBuiltin, ZEND_ACC_PUBLIC)
            ZEND_FE_END};

static const zend_function_entry class_ReflectionUnionType_methods[] = {
    ZEND_ME(ReflectionUnionType, getTypes, arginfo_class_ReflectionUnionType_getTypes, ZEND_ACC_PUBLIC) ZEND_FE_END};

static const zend_function_entry class_ReflectionIntersectionType_methods[] = {
    ZEND_ME(ReflectionIntersectionType, getTypes, arginfo_class_ReflectionIntersectionType_getTypes, ZEND_ACC_PUBLIC)
        ZEND_FE_END};

static const zend_function_entry class_ReflectionExtension_methods[] = {
    ZEND_RAW_FENTRY(
        "__clone", zim_ReflectionClass___clone, arginfo_class_ReflectionExtension___clone, ZEND_ACC_PRIVATE, NULL, NULL)
        ZEND_ME(ReflectionExtension, __construct, arginfo_class_ReflectionExtension___construct, ZEND_ACC_PUBLIC)
            ZEND_ME(ReflectionExtension, __toString, arginfo_class_ReflectionExtension___toString, ZEND_ACC_PUBLIC)
                ZEND_ME(ReflectionExtension, getName, arginfo_class_ReflectionExtension_getName, ZEND_ACC_PUBLIC)
                    ZEND_ME(
                        ReflectionExtension, getVersion, arginfo_class_ReflectionExtension_getVersion, ZEND_ACC_PUBLIC)
                        ZEND_ME(ReflectionExtension,
                                getFunctions,
                                arginfo_class_ReflectionExtension_getFunctions,
                                ZEND_ACC_PUBLIC) ZEND_ME(ReflectionExtension,
                                                         getConstants,
                                                         arginfo_class_ReflectionExtension_getConstants,
                                                         ZEND_ACC_PUBLIC)
                            ZEND_ME(ReflectionExtension,
                                    getINIEntries,
                                    arginfo_class_ReflectionExtension_getINIEntries,
                                    ZEND_ACC_PUBLIC) ZEND_ME(ReflectionExtension,
                                                             getClasses,
                                                             arginfo_class_ReflectionExtension_getClasses,
                                                             ZEND_ACC_PUBLIC)
                                ZEND_ME(ReflectionExtension,
                                        getClassNames,
                                        arginfo_class_ReflectionExtension_getClassNames,
                                        ZEND_ACC_PUBLIC) ZEND_ME(ReflectionExtension,
                                                                 getDependencies,
                                                                 arginfo_class_ReflectionExtension_getDependencies,
                                                                 ZEND_ACC_PUBLIC)
                                    ZEND_ME(ReflectionExtension,
                                            info,
                                            arginfo_class_ReflectionExtension_info,
                                            ZEND_ACC_PUBLIC) ZEND_ME(ReflectionExtension,
                                                                     isPersistent,
                                                                     arginfo_class_ReflectionExtension_isPersistent,
                                                                     ZEND_ACC_PUBLIC)
                                        ZEND_ME(ReflectionExtension,
                                                isTemporary,
                                                arginfo_class_ReflectionExtension_isTemporary,
                                                ZEND_ACC_PUBLIC) ZEND_FE_END};

static const zend_function_entry class_ReflectionZendExtension_methods[] = {
    ZEND_RAW_FENTRY("__clone",
                    zim_ReflectionClass___clone,
                    arginfo_class_ReflectionZendExtension___clone,
                    ZEND_ACC_PRIVATE,
                    NULL,
                    NULL) ZEND_ME(ReflectionZendExtension,
                                  __construct,
                                  arginfo_class_ReflectionZendExtension___construct,
                                  ZEND_ACC_PUBLIC)
        ZEND_ME(ReflectionZendExtension, __toString, arginfo_class_ReflectionZendExtension___toString, ZEND_ACC_PUBLIC)
            ZEND_ME(ReflectionZendExtension, getName, arginfo_class_ReflectionZendExtension_getName, ZEND_ACC_PUBLIC)
                ZEND_ME(ReflectionZendExtension,
                        getVersion,
                        arginfo_class_ReflectionZendExtension_getVersion,
                        ZEND_ACC_PUBLIC) ZEND_ME(ReflectionZendExtension,
                                                 getAuthor,
                                                 arginfo_class_ReflectionZendExtension_getAuthor,
                                                 ZEND_ACC_PUBLIC)
                    ZEND_ME(
                        ReflectionZendExtension, getURL, arginfo_class_ReflectionZendExtension_getURL, ZEND_ACC_PUBLIC)
                        ZEND_ME(ReflectionZendExtension,
                                getCopyright,
                                arginfo_class_ReflectionZendExtension_getCopyright,
                                ZEND_ACC_PUBLIC) ZEND_FE_END};

static const zend_function_entry class_ReflectionReference_methods[] = {
    ZEND_ME(ReflectionReference,
            fromArrayElement,
            arginfo_class_ReflectionReference_fromArrayElement,
            ZEND_ACC_PUBLIC | ZEND_ACC_STATIC)
        ZEND_ME(ReflectionReference, getId, arginfo_class_ReflectionReference_getId, ZEND_ACC_PUBLIC) ZEND_RAW_FENTRY(
            "__clone",
            zim_ReflectionClass___clone,
            arginfo_class_ReflectionReference___clone,
            ZEND_ACC_PRIVATE,
            NULL,
            NULL)
            ZEND_ME(ReflectionReference, __construct, arginfo_class_ReflectionReference___construct, ZEND_ACC_PRIVATE)
                ZEND_FE_END};

static const zend_function_entry class_ReflectionAttribute_methods[] = {
    ZEND_ME(ReflectionAttribute, getName, arginfo_class_ReflectionAttribute_getName, ZEND_ACC_PUBLIC) ZEND_ME(
        ReflectionAttribute, getTarget, arginfo_class_ReflectionAttribute_getTarget, ZEND_ACC_PUBLIC)
        ZEND_ME(ReflectionAttribute, isRepeated, arginfo_class_ReflectionAttribute_isRepeated, ZEND_ACC_PUBLIC) ZEND_ME(
            ReflectionAttribute, getArguments, arginfo_class_ReflectionAttribute_getArguments, ZEND_ACC_PUBLIC)
            ZEND_ME(ReflectionAttribute, newInstance, arginfo_class_ReflectionAttribute_newInstance, ZEND_ACC_PUBLIC)
                ZEND_ME(ReflectionAttribute, __toString, arginfo_class_ReflectionAttribute___toString, ZEND_ACC_PUBLIC)
                    ZEND_ME(ReflectionAttribute, __clone, arginfo_class_ReflectionAttribute___clone, ZEND_ACC_PRIVATE)
                        ZEND_ME(ReflectionAttribute,
                                __construct,
                                arginfo_class_ReflectionAttribute___construct,
                                ZEND_ACC_PRIVATE) ZEND_FE_END};

static const zend_function_entry class_ReflectionEnum_methods[] = {
    ZEND_ME(ReflectionEnum, __construct, arginfo_class_ReflectionEnum___construct, ZEND_ACC_PUBLIC)
        ZEND_ME(ReflectionEnum, hasCase, arginfo_class_ReflectionEnum_hasCase, ZEND_ACC_PUBLIC)
            ZEND_ME(ReflectionEnum, getCase, arginfo_class_ReflectionEnum_getCase, ZEND_ACC_PUBLIC)
                ZEND_ME(ReflectionEnum, getCases, arginfo_class_ReflectionEnum_getCases, ZEND_ACC_PUBLIC)
                    ZEND_ME(ReflectionEnum, isBacked, arginfo_class_ReflectionEnum_isBacked, ZEND_ACC_PUBLIC) ZEND_ME(
                        ReflectionEnum, getBackingType, arginfo_class_ReflectionEnum_getBackingType, ZEND_ACC_PUBLIC)
                        ZEND_FE_END};

static const zend_function_entry class_ReflectionEnumUnitCase_methods[] = {
    ZEND_ME(ReflectionEnumUnitCase, __construct, arginfo_class_ReflectionEnumUnitCase___construct, ZEND_ACC_PUBLIC)
        ZEND_ME(ReflectionEnumUnitCase, getEnum, arginfo_class_ReflectionEnumUnitCase_getEnum, ZEND_ACC_PUBLIC)
            ZEND_RAW_FENTRY("getValue",
                            zim_ReflectionClassConstant_getValue,
                            arginfo_class_ReflectionEnumUnitCase_getValue,
                            ZEND_ACC_PUBLIC,
                            NULL,
                            NULL) ZEND_FE_END};

static const zend_function_entry class_ReflectionEnumBackedCase_methods[] = {
    ZEND_ME(ReflectionEnumBackedCase, __construct, arginfo_class_ReflectionEnumBackedCase___construct, ZEND_ACC_PUBLIC)
        ZEND_ME(ReflectionEnumBackedCase,
                getBackingValue,
                arginfo_class_ReflectionEnumBackedCase_getBackingValue,
                ZEND_ACC_PUBLIC) ZEND_FE_END};

static const zend_function_entry class_ReflectionFiber_methods[] = {
    ZEND_ME(ReflectionFiber, __construct, arginfo_class_ReflectionFiber___construct, ZEND_ACC_PUBLIC)
        ZEND_ME(ReflectionFiber, getFiber, arginfo_class_ReflectionFiber_getFiber, ZEND_ACC_PUBLIC) ZEND_ME(
            ReflectionFiber, getExecutingFile, arginfo_class_ReflectionFiber_getExecutingFile, ZEND_ACC_PUBLIC)
            ZEND_ME(ReflectionFiber, getExecutingLine, arginfo_class_ReflectionFiber_getExecutingLine, ZEND_ACC_PUBLIC)
                ZEND_ME(ReflectionFiber, getCallable, arginfo_class_ReflectionFiber_getCallable, ZEND_ACC_PUBLIC)
                    ZEND_ME(ReflectionFiber, getTrace, arginfo_class_ReflectionFiber_getTrace, ZEND_ACC_PUBLIC)
                        ZEND_FE_END};

static const zend_function_entry class_ReflectionConstant_methods[] = {
    ZEND_ME(ReflectionConstant, __construct, arginfo_class_ReflectionConstant___construct, ZEND_ACC_PUBLIC)
        ZEND_ME(ReflectionConstant, getName, arginfo_class_ReflectionConstant_getName, ZEND_ACC_PUBLIC) ZEND_ME(
            ReflectionConstant, getNamespaceName, arginfo_class_ReflectionConstant_getNamespaceName, ZEND_ACC_PUBLIC)
            ZEND_ME(ReflectionConstant, getShortName, arginfo_class_ReflectionConstant_getShortName, ZEND_ACC_PUBLIC)
                ZEND_ME(ReflectionConstant, getValue, arginfo_class_ReflectionConstant_getValue, ZEND_ACC_PUBLIC)
                    ZEND_ME(ReflectionConstant,
                            isDeprecated,
                            arginfo_class_ReflectionConstant_isDeprecated,
                            ZEND_ACC_PUBLIC) ZEND_ME(ReflectionConstant,
                                                     __toString,
                                                     arginfo_class_ReflectionConstant___toString,
                                                     ZEND_ACC_PUBLIC) ZEND_FE_END};

static zend_class_entry* register_class_ReflectionException(zend_class_entry* class_entry_Exception)
{
    zend_class_entry ce, *class_entry;

    INIT_CLASS_ENTRY(ce, "ReflectionException", NULL);
    class_entry = zend_register_internal_class_with_flags(&ce, class_entry_Exception, 0);

    return class_entry;
}

static zend_class_entry* register_class_Reflection(void)
{
    zend_class_entry ce, *class_entry;

    INIT_CLASS_ENTRY(ce, "Reflection", class_Reflection_methods);
    class_entry = zend_register_internal_class_with_flags(&ce, NULL, 0);

    return class_entry;
}

static zend_class_entry* register_class_Reflector(zend_class_entry* class_entry_Stringable)
{
    zend_class_entry ce, *class_entry;

    INIT_CLASS_ENTRY(ce, "Reflector", NULL);
    class_entry = zend_register_internal_interface(&ce);
    zend_class_implements(class_entry, 1, class_entry_Stringable);

    return class_entry;
}

static zend_class_entry* register_class_ReflectionFunctionAbstract(zend_class_entry* class_entry_Reflector)
{
    zend_class_entry ce, *class_entry;

    INIT_CLASS_ENTRY(ce, "ReflectionFunctionAbstract", class_ReflectionFunctionAbstract_methods);
    class_entry = zend_register_internal_class_with_flags(&ce, NULL, ZEND_ACC_ABSTRACT | ZEND_ACC_NOT_SERIALIZABLE);
    zend_class_implements(class_entry, 1, class_entry_Reflector);

    zval property_name_default_value;
    ZVAL_UNDEF(&property_name_default_value);
    zend_string* property_name_name = zend_string_init("name", sizeof("name") - 1, 1);
    zend_declare_typed_property(class_entry,
                                property_name_name,
                                &property_name_default_value,
                                ZEND_ACC_PUBLIC,
                                NULL,
                                (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_STRING));
    zend_string_release(property_name_name);

    return class_entry;
}

static zend_class_entry* register_class_ReflectionFunction(zend_class_entry* class_entry_ReflectionFunctionAbstract)
{
    zend_class_entry ce, *class_entry;

    INIT_CLASS_ENTRY(ce, "ReflectionFunction", class_ReflectionFunction_methods);
    class_entry = zend_register_internal_class_with_flags(&ce, class_entry_ReflectionFunctionAbstract, 0);

    zval const_IS_DEPRECATED_value;
    ZVAL_LONG(&const_IS_DEPRECATED_value, ZEND_ACC_DEPRECATED);
    zend_string* const_IS_DEPRECATED_name = zend_string_init_interned("IS_DEPRECATED", sizeof("IS_DEPRECATED") - 1, 1);
    zend_declare_typed_class_constant(class_entry,
                                      const_IS_DEPRECATED_name,
                                      &const_IS_DEPRECATED_value,
                                      ZEND_ACC_PUBLIC,
                                      NULL,
                                      (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_LONG));
    zend_string_release(const_IS_DEPRECATED_name);

    zend_attribute* attribute_Deprecated_func_isdisabled_0 = zend_add_function_attribute(
        zend_hash_str_find_ptr(&class_entry->function_table, "isdisabled", sizeof("isdisabled") - 1),
        ZSTR_KNOWN(ZEND_STR_DEPRECATED_CAPITALIZED),
        2);
    zval attribute_Deprecated_func_isdisabled_0_arg0;
    zend_string* attribute_Deprecated_func_isdisabled_0_arg0_str = zend_string_init("8.0", strlen("8.0"), 1);
    ZVAL_STR(&attribute_Deprecated_func_isdisabled_0_arg0, attribute_Deprecated_func_isdisabled_0_arg0_str);
    ZVAL_COPY_VALUE(&attribute_Deprecated_func_isdisabled_0->args[0].value,
                    &attribute_Deprecated_func_isdisabled_0_arg0);
    attribute_Deprecated_func_isdisabled_0->args[0].name = ZSTR_KNOWN(ZEND_STR_SINCE);
    zval attribute_Deprecated_func_isdisabled_0_arg1;
    zend_string* attribute_Deprecated_func_isdisabled_0_arg1_str =
        zend_string_init("as ReflectionFunction can no longer be constructed for disabled functions",
                         strlen("as ReflectionFunction can no longer be constructed for disabled functions"),
                         1);
    ZVAL_STR(&attribute_Deprecated_func_isdisabled_0_arg1, attribute_Deprecated_func_isdisabled_0_arg1_str);
    ZVAL_COPY_VALUE(&attribute_Deprecated_func_isdisabled_0->args[1].value,
                    &attribute_Deprecated_func_isdisabled_0_arg1);
    attribute_Deprecated_func_isdisabled_0->args[1].name = ZSTR_KNOWN(ZEND_STR_MESSAGE);

    return class_entry;
}

static zend_class_entry* register_class_ReflectionGenerator(void)
{
    zend_class_entry ce, *class_entry;

    INIT_CLASS_ENTRY(ce, "ReflectionGenerator", class_ReflectionGenerator_methods);
    class_entry = zend_register_internal_class_with_flags(&ce, NULL, ZEND_ACC_FINAL | ZEND_ACC_NOT_SERIALIZABLE);

    return class_entry;
}

static zend_class_entry* register_class_ReflectionMethod(zend_class_entry* class_entry_ReflectionFunctionAbstract)
{
    zend_class_entry ce, *class_entry;

    INIT_CLASS_ENTRY(ce, "ReflectionMethod", class_ReflectionMethod_methods);
    class_entry = zend_register_internal_class_with_flags(&ce, class_entry_ReflectionFunctionAbstract, 0);

    zval const_IS_STATIC_value;
    ZVAL_LONG(&const_IS_STATIC_value, ZEND_ACC_STATIC);
    zend_string* const_IS_STATIC_name = zend_string_init_interned("IS_STATIC", sizeof("IS_STATIC") - 1, 1);
    zend_declare_typed_class_constant(class_entry,
                                      const_IS_STATIC_name,
                                      &const_IS_STATIC_value,
                                      ZEND_ACC_PUBLIC,
                                      NULL,
                                      (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_LONG));
    zend_string_release(const_IS_STATIC_name);

    zval const_IS_PUBLIC_value;
    ZVAL_LONG(&const_IS_PUBLIC_value, ZEND_ACC_PUBLIC);
    zend_string* const_IS_PUBLIC_name = zend_string_init_interned("IS_PUBLIC", sizeof("IS_PUBLIC") - 1, 1);
    zend_declare_typed_class_constant(class_entry,
                                      const_IS_PUBLIC_name,
                                      &const_IS_PUBLIC_value,
                                      ZEND_ACC_PUBLIC,
                                      NULL,
                                      (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_LONG));
    zend_string_release(const_IS_PUBLIC_name);

    zval const_IS_PROTECTED_value;
    ZVAL_LONG(&const_IS_PROTECTED_value, ZEND_ACC_PROTECTED);
    zend_string* const_IS_PROTECTED_name = zend_string_init_interned("IS_PROTECTED", sizeof("IS_PROTECTED") - 1, 1);
    zend_declare_typed_class_constant(class_entry,
                                      const_IS_PROTECTED_name,
                                      &const_IS_PROTECTED_value,
                                      ZEND_ACC_PUBLIC,
                                      NULL,
                                      (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_LONG));
    zend_string_release(const_IS_PROTECTED_name);

    zval const_IS_PRIVATE_value;
    ZVAL_LONG(&const_IS_PRIVATE_value, ZEND_ACC_PRIVATE);
    zend_string* const_IS_PRIVATE_name = zend_string_init_interned("IS_PRIVATE", sizeof("IS_PRIVATE") - 1, 1);
    zend_declare_typed_class_constant(class_entry,
                                      const_IS_PRIVATE_name,
                                      &const_IS_PRIVATE_value,
                                      ZEND_ACC_PUBLIC,
                                      NULL,
                                      (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_LONG));
    zend_string_release(const_IS_PRIVATE_name);

    zval const_IS_ABSTRACT_value;
    ZVAL_LONG(&const_IS_ABSTRACT_value, ZEND_ACC_ABSTRACT);
    zend_string* const_IS_ABSTRACT_name = zend_string_init_interned("IS_ABSTRACT", sizeof("IS_ABSTRACT") - 1, 1);
    zend_declare_typed_class_constant(class_entry,
                                      const_IS_ABSTRACT_name,
                                      &const_IS_ABSTRACT_value,
                                      ZEND_ACC_PUBLIC,
                                      NULL,
                                      (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_LONG));
    zend_string_release(const_IS_ABSTRACT_name);

    zval const_IS_FINAL_value;
    ZVAL_LONG(&const_IS_FINAL_value, ZEND_ACC_FINAL);
    zend_string* const_IS_FINAL_name = zend_string_init_interned("IS_FINAL", sizeof("IS_FINAL") - 1, 1);
    zend_declare_typed_class_constant(class_entry,
                                      const_IS_FINAL_name,
                                      &const_IS_FINAL_value,
                                      ZEND_ACC_PUBLIC,
                                      NULL,
                                      (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_LONG));
    zend_string_release(const_IS_FINAL_name);

    zval property_class_default_value;
    ZVAL_UNDEF(&property_class_default_value);
    zend_string* property_class_name = zend_string_init("class", sizeof("class") - 1, 1);
    zend_declare_typed_property(class_entry,
                                property_class_name,
                                &property_class_default_value,
                                ZEND_ACC_PUBLIC,
                                NULL,
                                (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_STRING));
    zend_string_release(property_class_name);

    return class_entry;
}

static zend_class_entry* register_class_ReflectionClass(zend_class_entry* class_entry_Reflector)
{
    zend_class_entry ce, *class_entry;

    INIT_CLASS_ENTRY(ce, "ReflectionClass", class_ReflectionClass_methods);
    class_entry = zend_register_internal_class_with_flags(&ce, NULL, ZEND_ACC_NOT_SERIALIZABLE);
    zend_class_implements(class_entry, 1, class_entry_Reflector);

    zval const_IS_IMPLICIT_ABSTRACT_value;
    ZVAL_LONG(&const_IS_IMPLICIT_ABSTRACT_value, ZEND_ACC_IMPLICIT_ABSTRACT_CLASS);
    zend_string* const_IS_IMPLICIT_ABSTRACT_name =
        zend_string_init_interned("IS_IMPLICIT_ABSTRACT", sizeof("IS_IMPLICIT_ABSTRACT") - 1, 1);
    zend_declare_typed_class_constant(class_entry,
                                      const_IS_IMPLICIT_ABSTRACT_name,
                                      &const_IS_IMPLICIT_ABSTRACT_value,
                                      ZEND_ACC_PUBLIC,
                                      NULL,
                                      (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_LONG));
    zend_string_release(const_IS_IMPLICIT_ABSTRACT_name);

    zval const_IS_EXPLICIT_ABSTRACT_value;
    ZVAL_LONG(&const_IS_EXPLICIT_ABSTRACT_value, ZEND_ACC_EXPLICIT_ABSTRACT_CLASS);
    zend_string* const_IS_EXPLICIT_ABSTRACT_name =
        zend_string_init_interned("IS_EXPLICIT_ABSTRACT", sizeof("IS_EXPLICIT_ABSTRACT") - 1, 1);
    zend_declare_typed_class_constant(class_entry,
                                      const_IS_EXPLICIT_ABSTRACT_name,
                                      &const_IS_EXPLICIT_ABSTRACT_value,
                                      ZEND_ACC_PUBLIC,
                                      NULL,
                                      (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_LONG));
    zend_string_release(const_IS_EXPLICIT_ABSTRACT_name);

    zval const_IS_FINAL_value;
    ZVAL_LONG(&const_IS_FINAL_value, ZEND_ACC_FINAL);
    zend_string* const_IS_FINAL_name = zend_string_init_interned("IS_FINAL", sizeof("IS_FINAL") - 1, 1);
    zend_declare_typed_class_constant(class_entry,
                                      const_IS_FINAL_name,
                                      &const_IS_FINAL_value,
                                      ZEND_ACC_PUBLIC,
                                      NULL,
                                      (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_LONG));
    zend_string_release(const_IS_FINAL_name);

    zval const_IS_READONLY_value;
    ZVAL_LONG(&const_IS_READONLY_value, ZEND_ACC_READONLY_CLASS);
    zend_string* const_IS_READONLY_name = zend_string_init_interned("IS_READONLY", sizeof("IS_READONLY") - 1, 1);
    zend_declare_typed_class_constant(class_entry,
                                      const_IS_READONLY_name,
                                      &const_IS_READONLY_value,
                                      ZEND_ACC_PUBLIC,
                                      NULL,
                                      (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_LONG));
    zend_string_release(const_IS_READONLY_name);

    zval const_SKIP_INITIALIZATION_ON_SERIALIZE_value;
    ZVAL_LONG(&const_SKIP_INITIALIZATION_ON_SERIALIZE_value, ZEND_LAZY_OBJECT_SKIP_INITIALIZATION_ON_SERIALIZE);
    zend_string* const_SKIP_INITIALIZATION_ON_SERIALIZE_name = zend_string_init_interned(
        "SKIP_INITIALIZATION_ON_SERIALIZE", sizeof("SKIP_INITIALIZATION_ON_SERIALIZE") - 1, 1);
    zend_declare_typed_class_constant(class_entry,
                                      const_SKIP_INITIALIZATION_ON_SERIALIZE_name,
                                      &const_SKIP_INITIALIZATION_ON_SERIALIZE_value,
                                      ZEND_ACC_PUBLIC,
                                      NULL,
                                      (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_LONG));
    zend_string_release(const_SKIP_INITIALIZATION_ON_SERIALIZE_name);

    zval const_SKIP_DESTRUCTOR_value;
    ZVAL_LONG(&const_SKIP_DESTRUCTOR_value, ZEND_LAZY_OBJECT_SKIP_DESTRUCTOR);
    zend_string* const_SKIP_DESTRUCTOR_name =
        zend_string_init_interned("SKIP_DESTRUCTOR", sizeof("SKIP_DESTRUCTOR") - 1, 1);
    zend_declare_typed_class_constant(class_entry,
                                      const_SKIP_DESTRUCTOR_name,
                                      &const_SKIP_DESTRUCTOR_value,
                                      ZEND_ACC_PUBLIC,
                                      NULL,
                                      (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_LONG));
    zend_string_release(const_SKIP_DESTRUCTOR_name);

    zval property_name_default_value;
    ZVAL_UNDEF(&property_name_default_value);
    zend_string* property_name_name = zend_string_init("name", sizeof("name") - 1, 1);
    zend_declare_typed_property(class_entry,
                                property_name_name,
                                &property_name_default_value,
                                ZEND_ACC_PUBLIC,
                                NULL,
                                (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_STRING));
    zend_string_release(property_name_name);

    return class_entry;
}

static zend_class_entry* register_class_ReflectionObject(zend_class_entry* class_entry_ReflectionClass)
{
    zend_class_entry ce, *class_entry;

    INIT_CLASS_ENTRY(ce, "ReflectionObject", class_ReflectionObject_methods);
    class_entry = zend_register_internal_class_with_flags(&ce, class_entry_ReflectionClass, 0);

    return class_entry;
}

static zend_class_entry* register_class_PropertyHookType(void)
{
    zend_class_entry* class_entry = zend_register_internal_enum("PropertyHookType", IS_STRING, NULL);

    zval enum_case_Get_value;
    zend_string* enum_case_Get_value_str = zend_string_init("get", strlen("get"), 1);
    ZVAL_STR(&enum_case_Get_value, enum_case_Get_value_str);
    zend_enum_add_case_cstr(class_entry, "Get", &enum_case_Get_value);

    zval enum_case_Set_value;
    zend_string* enum_case_Set_value_str = zend_string_init("set", strlen("set"), 1);
    ZVAL_STR(&enum_case_Set_value, enum_case_Set_value_str);
    zend_enum_add_case_cstr(class_entry, "Set", &enum_case_Set_value);

    return class_entry;
}

static zend_class_entry* register_class_ReflectionProperty(zend_class_entry* class_entry_Reflector)
{
    zend_class_entry ce, *class_entry;

    INIT_CLASS_ENTRY(ce, "ReflectionProperty", class_ReflectionProperty_methods);
    class_entry = zend_register_internal_class_with_flags(&ce, NULL, ZEND_ACC_NOT_SERIALIZABLE);
    zend_class_implements(class_entry, 1, class_entry_Reflector);

    zval const_IS_STATIC_value;
    ZVAL_LONG(&const_IS_STATIC_value, ZEND_ACC_STATIC);
    zend_string* const_IS_STATIC_name = zend_string_init_interned("IS_STATIC", sizeof("IS_STATIC") - 1, 1);
    zend_declare_typed_class_constant(class_entry,
                                      const_IS_STATIC_name,
                                      &const_IS_STATIC_value,
                                      ZEND_ACC_PUBLIC,
                                      NULL,
                                      (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_LONG));
    zend_string_release(const_IS_STATIC_name);

    zval const_IS_READONLY_value;
    ZVAL_LONG(&const_IS_READONLY_value, ZEND_ACC_READONLY);
    zend_string* const_IS_READONLY_name = zend_string_init_interned("IS_READONLY", sizeof("IS_READONLY") - 1, 1);
    zend_declare_typed_class_constant(class_entry,
                                      const_IS_READONLY_name,
                                      &const_IS_READONLY_value,
                                      ZEND_ACC_PUBLIC,
                                      NULL,
                                      (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_LONG));
    zend_string_release(const_IS_READONLY_name);

    zval const_IS_PUBLIC_value;
    ZVAL_LONG(&const_IS_PUBLIC_value, ZEND_ACC_PUBLIC);
    zend_string* const_IS_PUBLIC_name = zend_string_init_interned("IS_PUBLIC", sizeof("IS_PUBLIC") - 1, 1);
    zend_declare_typed_class_constant(class_entry,
                                      const_IS_PUBLIC_name,
                                      &const_IS_PUBLIC_value,
                                      ZEND_ACC_PUBLIC,
                                      NULL,
                                      (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_LONG));
    zend_string_release(const_IS_PUBLIC_name);

    zval const_IS_PROTECTED_value;
    ZVAL_LONG(&const_IS_PROTECTED_value, ZEND_ACC_PROTECTED);
    zend_string* const_IS_PROTECTED_name = zend_string_init_interned("IS_PROTECTED", sizeof("IS_PROTECTED") - 1, 1);
    zend_declare_typed_class_constant(class_entry,
                                      const_IS_PROTECTED_name,
                                      &const_IS_PROTECTED_value,
                                      ZEND_ACC_PUBLIC,
                                      NULL,
                                      (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_LONG));
    zend_string_release(const_IS_PROTECTED_name);

    zval const_IS_PRIVATE_value;
    ZVAL_LONG(&const_IS_PRIVATE_value, ZEND_ACC_PRIVATE);
    zend_string* const_IS_PRIVATE_name = zend_string_init_interned("IS_PRIVATE", sizeof("IS_PRIVATE") - 1, 1);
    zend_declare_typed_class_constant(class_entry,
                                      const_IS_PRIVATE_name,
                                      &const_IS_PRIVATE_value,
                                      ZEND_ACC_PUBLIC,
                                      NULL,
                                      (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_LONG));
    zend_string_release(const_IS_PRIVATE_name);

    zval const_IS_ABSTRACT_value;
    ZVAL_LONG(&const_IS_ABSTRACT_value, ZEND_ACC_ABSTRACT);
    zend_string* const_IS_ABSTRACT_name = zend_string_init_interned("IS_ABSTRACT", sizeof("IS_ABSTRACT") - 1, 1);
    zend_declare_typed_class_constant(class_entry,
                                      const_IS_ABSTRACT_name,
                                      &const_IS_ABSTRACT_value,
                                      ZEND_ACC_PUBLIC,
                                      NULL,
                                      (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_LONG));
    zend_string_release(const_IS_ABSTRACT_name);

    zval const_IS_PROTECTED_SET_value;
    ZVAL_LONG(&const_IS_PROTECTED_SET_value, ZEND_ACC_PROTECTED_SET);
    zend_string* const_IS_PROTECTED_SET_name =
        zend_string_init_interned("IS_PROTECTED_SET", sizeof("IS_PROTECTED_SET") - 1, 1);
    zend_declare_typed_class_constant(class_entry,
                                      const_IS_PROTECTED_SET_name,
                                      &const_IS_PROTECTED_SET_value,
                                      ZEND_ACC_PUBLIC,
                                      NULL,
                                      (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_LONG));
    zend_string_release(const_IS_PROTECTED_SET_name);

    zval const_IS_PRIVATE_SET_value;
    ZVAL_LONG(&const_IS_PRIVATE_SET_value, ZEND_ACC_PRIVATE_SET);
    zend_string* const_IS_PRIVATE_SET_name =
        zend_string_init_interned("IS_PRIVATE_SET", sizeof("IS_PRIVATE_SET") - 1, 1);
    zend_declare_typed_class_constant(class_entry,
                                      const_IS_PRIVATE_SET_name,
                                      &const_IS_PRIVATE_SET_value,
                                      ZEND_ACC_PUBLIC,
                                      NULL,
                                      (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_LONG));
    zend_string_release(const_IS_PRIVATE_SET_name);

    zval const_IS_VIRTUAL_value;
    ZVAL_LONG(&const_IS_VIRTUAL_value, ZEND_ACC_VIRTUAL);
    zend_string* const_IS_VIRTUAL_name = zend_string_init_interned("IS_VIRTUAL", sizeof("IS_VIRTUAL") - 1, 1);
    zend_declare_typed_class_constant(class_entry,
                                      const_IS_VIRTUAL_name,
                                      &const_IS_VIRTUAL_value,
                                      ZEND_ACC_PUBLIC,
                                      NULL,
                                      (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_LONG));
    zend_string_release(const_IS_VIRTUAL_name);

    zval const_IS_FINAL_value;
    ZVAL_LONG(&const_IS_FINAL_value, ZEND_ACC_FINAL);
    zend_string* const_IS_FINAL_name = zend_string_init_interned("IS_FINAL", sizeof("IS_FINAL") - 1, 1);
    zend_declare_typed_class_constant(class_entry,
                                      const_IS_FINAL_name,
                                      &const_IS_FINAL_value,
                                      ZEND_ACC_PUBLIC,
                                      NULL,
                                      (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_LONG));
    zend_string_release(const_IS_FINAL_name);

    zval property_name_default_value;
    ZVAL_UNDEF(&property_name_default_value);
    zend_string* property_name_name = zend_string_init("name", sizeof("name") - 1, 1);
    zend_declare_typed_property(class_entry,
                                property_name_name,
                                &property_name_default_value,
                                ZEND_ACC_PUBLIC,
                                NULL,
                                (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_STRING));
    zend_string_release(property_name_name);

    zval property_class_default_value;
    ZVAL_UNDEF(&property_class_default_value);
    zend_string* property_class_name = zend_string_init("class", sizeof("class") - 1, 1);
    zend_declare_typed_property(class_entry,
                                property_class_name,
                                &property_class_default_value,
                                ZEND_ACC_PUBLIC,
                                NULL,
                                (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_STRING));
    zend_string_release(property_class_name);

    return class_entry;
}

static zend_class_entry* register_class_ReflectionClassConstant(zend_class_entry* class_entry_Reflector)
{
    zend_class_entry ce, *class_entry;

    INIT_CLASS_ENTRY(ce, "ReflectionClassConstant", class_ReflectionClassConstant_methods);
    class_entry = zend_register_internal_class_with_flags(&ce, NULL, ZEND_ACC_NOT_SERIALIZABLE);
    zend_class_implements(class_entry, 1, class_entry_Reflector);

    zval const_IS_PUBLIC_value;
    ZVAL_LONG(&const_IS_PUBLIC_value, ZEND_ACC_PUBLIC);
    zend_string* const_IS_PUBLIC_name = zend_string_init_interned("IS_PUBLIC", sizeof("IS_PUBLIC") - 1, 1);
    zend_declare_typed_class_constant(class_entry,
                                      const_IS_PUBLIC_name,
                                      &const_IS_PUBLIC_value,
                                      ZEND_ACC_PUBLIC,
                                      NULL,
                                      (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_LONG));
    zend_string_release(const_IS_PUBLIC_name);

    zval const_IS_PROTECTED_value;
    ZVAL_LONG(&const_IS_PROTECTED_value, ZEND_ACC_PROTECTED);
    zend_string* const_IS_PROTECTED_name = zend_string_init_interned("IS_PROTECTED", sizeof("IS_PROTECTED") - 1, 1);
    zend_declare_typed_class_constant(class_entry,
                                      const_IS_PROTECTED_name,
                                      &const_IS_PROTECTED_value,
                                      ZEND_ACC_PUBLIC,
                                      NULL,
                                      (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_LONG));
    zend_string_release(const_IS_PROTECTED_name);

    zval const_IS_PRIVATE_value;
    ZVAL_LONG(&const_IS_PRIVATE_value, ZEND_ACC_PRIVATE);
    zend_string* const_IS_PRIVATE_name = zend_string_init_interned("IS_PRIVATE", sizeof("IS_PRIVATE") - 1, 1);
    zend_declare_typed_class_constant(class_entry,
                                      const_IS_PRIVATE_name,
                                      &const_IS_PRIVATE_value,
                                      ZEND_ACC_PUBLIC,
                                      NULL,
                                      (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_LONG));
    zend_string_release(const_IS_PRIVATE_name);

    zval const_IS_FINAL_value;
    ZVAL_LONG(&const_IS_FINAL_value, ZEND_ACC_FINAL);
    zend_string* const_IS_FINAL_name = zend_string_init_interned("IS_FINAL", sizeof("IS_FINAL") - 1, 1);
    zend_declare_typed_class_constant(class_entry,
                                      const_IS_FINAL_name,
                                      &const_IS_FINAL_value,
                                      ZEND_ACC_PUBLIC,
                                      NULL,
                                      (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_LONG));
    zend_string_release(const_IS_FINAL_name);

    zval property_name_default_value;
    ZVAL_UNDEF(&property_name_default_value);
    zend_string* property_name_name = zend_string_init("name", sizeof("name") - 1, 1);
    zend_declare_typed_property(class_entry,
                                property_name_name,
                                &property_name_default_value,
                                ZEND_ACC_PUBLIC,
                                NULL,
                                (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_STRING));
    zend_string_release(property_name_name);

    zval property_class_default_value;
    ZVAL_UNDEF(&property_class_default_value);
    zend_string* property_class_name = zend_string_init("class", sizeof("class") - 1, 1);
    zend_declare_typed_property(class_entry,
                                property_class_name,
                                &property_class_default_value,
                                ZEND_ACC_PUBLIC,
                                NULL,
                                (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_STRING));
    zend_string_release(property_class_name);

    return class_entry;
}

static zend_class_entry* register_class_ReflectionParameter(zend_class_entry* class_entry_Reflector)
{
    zend_class_entry ce, *class_entry;

    INIT_CLASS_ENTRY(ce, "ReflectionParameter", class_ReflectionParameter_methods);
    class_entry = zend_register_internal_class_with_flags(&ce, NULL, ZEND_ACC_NOT_SERIALIZABLE);
    zend_class_implements(class_entry, 1, class_entry_Reflector);

    zval property_name_default_value;
    ZVAL_UNDEF(&property_name_default_value);
    zend_string* property_name_name = zend_string_init("name", sizeof("name") - 1, 1);
    zend_declare_typed_property(class_entry,
                                property_name_name,
                                &property_name_default_value,
                                ZEND_ACC_PUBLIC,
                                NULL,
                                (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_STRING));
    zend_string_release(property_name_name);

    zend_attribute* attribute_Deprecated_func_getclass_0 = zend_add_function_attribute(
        zend_hash_str_find_ptr(&class_entry->function_table, "getclass", sizeof("getclass") - 1),
        ZSTR_KNOWN(ZEND_STR_DEPRECATED_CAPITALIZED),
        2);
    zval attribute_Deprecated_func_getclass_0_arg0;
    zend_string* attribute_Deprecated_func_getclass_0_arg0_str = zend_string_init("8.0", strlen("8.0"), 1);
    ZVAL_STR(&attribute_Deprecated_func_getclass_0_arg0, attribute_Deprecated_func_getclass_0_arg0_str);
    ZVAL_COPY_VALUE(&attribute_Deprecated_func_getclass_0->args[0].value, &attribute_Deprecated_func_getclass_0_arg0);
    attribute_Deprecated_func_getclass_0->args[0].name = ZSTR_KNOWN(ZEND_STR_SINCE);
    zval attribute_Deprecated_func_getclass_0_arg1;
    zend_string* attribute_Deprecated_func_getclass_0_arg1_str = zend_string_init(
        "use ReflectionParameter::getType() instead", strlen("use ReflectionParameter::getType() instead"), 1);
    ZVAL_STR(&attribute_Deprecated_func_getclass_0_arg1, attribute_Deprecated_func_getclass_0_arg1_str);
    ZVAL_COPY_VALUE(&attribute_Deprecated_func_getclass_0->args[1].value, &attribute_Deprecated_func_getclass_0_arg1);
    attribute_Deprecated_func_getclass_0->args[1].name = ZSTR_KNOWN(ZEND_STR_MESSAGE);

    zend_attribute* attribute_Deprecated_func_isarray_0 = zend_add_function_attribute(
        zend_hash_str_find_ptr(&class_entry->function_table, "isarray", sizeof("isarray") - 1),
        ZSTR_KNOWN(ZEND_STR_DEPRECATED_CAPITALIZED),
        2);
    zval attribute_Deprecated_func_isarray_0_arg0;
    zend_string* attribute_Deprecated_func_isarray_0_arg0_str = zend_string_init("8.0", strlen("8.0"), 1);
    ZVAL_STR(&attribute_Deprecated_func_isarray_0_arg0, attribute_Deprecated_func_isarray_0_arg0_str);
    ZVAL_COPY_VALUE(&attribute_Deprecated_func_isarray_0->args[0].value, &attribute_Deprecated_func_isarray_0_arg0);
    attribute_Deprecated_func_isarray_0->args[0].name = ZSTR_KNOWN(ZEND_STR_SINCE);
    zval attribute_Deprecated_func_isarray_0_arg1;
    zend_string* attribute_Deprecated_func_isarray_0_arg1_str = zend_string_init(
        "use ReflectionParameter::getType() instead", strlen("use ReflectionParameter::getType() instead"), 1);
    ZVAL_STR(&attribute_Deprecated_func_isarray_0_arg1, attribute_Deprecated_func_isarray_0_arg1_str);
    ZVAL_COPY_VALUE(&attribute_Deprecated_func_isarray_0->args[1].value, &attribute_Deprecated_func_isarray_0_arg1);
    attribute_Deprecated_func_isarray_0->args[1].name = ZSTR_KNOWN(ZEND_STR_MESSAGE);

    zend_attribute* attribute_Deprecated_func_iscallable_0 = zend_add_function_attribute(
        zend_hash_str_find_ptr(&class_entry->function_table, "iscallable", sizeof("iscallable") - 1),
        ZSTR_KNOWN(ZEND_STR_DEPRECATED_CAPITALIZED),
        2);
    zval attribute_Deprecated_func_iscallable_0_arg0;
    zend_string* attribute_Deprecated_func_iscallable_0_arg0_str = zend_string_init("8.0", strlen("8.0"), 1);
    ZVAL_STR(&attribute_Deprecated_func_iscallable_0_arg0, attribute_Deprecated_func_iscallable_0_arg0_str);
    ZVAL_COPY_VALUE(&attribute_Deprecated_func_iscallable_0->args[0].value,
                    &attribute_Deprecated_func_iscallable_0_arg0);
    attribute_Deprecated_func_iscallable_0->args[0].name = ZSTR_KNOWN(ZEND_STR_SINCE);
    zval attribute_Deprecated_func_iscallable_0_arg1;
    zend_string* attribute_Deprecated_func_iscallable_0_arg1_str = zend_string_init(
        "use ReflectionParameter::getType() instead", strlen("use ReflectionParameter::getType() instead"), 1);
    ZVAL_STR(&attribute_Deprecated_func_iscallable_0_arg1, attribute_Deprecated_func_iscallable_0_arg1_str);
    ZVAL_COPY_VALUE(&attribute_Deprecated_func_iscallable_0->args[1].value,
                    &attribute_Deprecated_func_iscallable_0_arg1);
    attribute_Deprecated_func_iscallable_0->args[1].name = ZSTR_KNOWN(ZEND_STR_MESSAGE);

    return class_entry;
}

static zend_class_entry* register_class_ReflectionType(zend_class_entry* class_entry_Stringable)
{
    zend_class_entry ce, *class_entry;

    INIT_CLASS_ENTRY(ce, "ReflectionType", class_ReflectionType_methods);
    class_entry = zend_register_internal_class_with_flags(&ce, NULL, ZEND_ACC_ABSTRACT | ZEND_ACC_NOT_SERIALIZABLE);
    zend_class_implements(class_entry, 1, class_entry_Stringable);

    return class_entry;
}

static zend_class_entry* register_class_ReflectionNamedType(zend_class_entry* class_entry_ReflectionType)
{
    zend_class_entry ce, *class_entry;

    INIT_CLASS_ENTRY(ce, "ReflectionNamedType", class_ReflectionNamedType_methods);
    class_entry = zend_register_internal_class_with_flags(&ce, class_entry_ReflectionType, 0);

    return class_entry;
}

static zend_class_entry* register_class_ReflectionUnionType(zend_class_entry* class_entry_ReflectionType)
{
    zend_class_entry ce, *class_entry;

    INIT_CLASS_ENTRY(ce, "ReflectionUnionType", class_ReflectionUnionType_methods);
    class_entry = zend_register_internal_class_with_flags(&ce, class_entry_ReflectionType, 0);

    return class_entry;
}

static zend_class_entry* register_class_ReflectionIntersectionType(zend_class_entry* class_entry_ReflectionType)
{
    zend_class_entry ce, *class_entry;

    INIT_CLASS_ENTRY(ce, "ReflectionIntersectionType", class_ReflectionIntersectionType_methods);
    class_entry = zend_register_internal_class_with_flags(&ce, class_entry_ReflectionType, 0);

    return class_entry;
}

static zend_class_entry* register_class_ReflectionExtension(zend_class_entry* class_entry_Reflector)
{
    zend_class_entry ce, *class_entry;

    INIT_CLASS_ENTRY(ce, "ReflectionExtension", class_ReflectionExtension_methods);
    class_entry = zend_register_internal_class_with_flags(&ce, NULL, ZEND_ACC_NOT_SERIALIZABLE);
    zend_class_implements(class_entry, 1, class_entry_Reflector);

    zval property_name_default_value;
    ZVAL_UNDEF(&property_name_default_value);
    zend_string* property_name_name = zend_string_init("name", sizeof("name") - 1, 1);
    zend_declare_typed_property(class_entry,
                                property_name_name,
                                &property_name_default_value,
                                ZEND_ACC_PUBLIC,
                                NULL,
                                (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_STRING));
    zend_string_release(property_name_name);

    return class_entry;
}

static zend_class_entry* register_class_ReflectionZendExtension(zend_class_entry* class_entry_Reflector)
{
    zend_class_entry ce, *class_entry;

    INIT_CLASS_ENTRY(ce, "ReflectionZendExtension", class_ReflectionZendExtension_methods);
    class_entry = zend_register_internal_class_with_flags(&ce, NULL, ZEND_ACC_NOT_SERIALIZABLE);
    zend_class_implements(class_entry, 1, class_entry_Reflector);

    zval property_name_default_value;
    ZVAL_UNDEF(&property_name_default_value);
    zend_string* property_name_name = zend_string_init("name", sizeof("name") - 1, 1);
    zend_declare_typed_property(class_entry,
                                property_name_name,
                                &property_name_default_value,
                                ZEND_ACC_PUBLIC,
                                NULL,
                                (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_STRING));
    zend_string_release(property_name_name);

    return class_entry;
}

static zend_class_entry* register_class_ReflectionReference(void)
{
    zend_class_entry ce, *class_entry;

    INIT_CLASS_ENTRY(ce, "ReflectionReference", class_ReflectionReference_methods);
    class_entry = zend_register_internal_class_with_flags(&ce, NULL, ZEND_ACC_FINAL | ZEND_ACC_NOT_SERIALIZABLE);

    return class_entry;
}

static zend_class_entry* register_class_ReflectionAttribute(zend_class_entry* class_entry_Reflector)
{
    zend_class_entry ce, *class_entry;

    INIT_CLASS_ENTRY(ce, "ReflectionAttribute", class_ReflectionAttribute_methods);
    class_entry = zend_register_internal_class_with_flags(&ce, NULL, ZEND_ACC_NOT_SERIALIZABLE);
    zend_class_implements(class_entry, 1, class_entry_Reflector);

    zval const_IS_INSTANCEOF_value;
    ZVAL_LONG(&const_IS_INSTANCEOF_value, REFLECTION_ATTRIBUTE_IS_INSTANCEOF);
    zend_string* const_IS_INSTANCEOF_name = zend_string_init_interned("IS_INSTANCEOF", sizeof("IS_INSTANCEOF") - 1, 1);
    zend_declare_typed_class_constant(class_entry,
                                      const_IS_INSTANCEOF_name,
                                      &const_IS_INSTANCEOF_value,
                                      ZEND_ACC_PUBLIC,
                                      NULL,
                                      (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_LONG));
    zend_string_release(const_IS_INSTANCEOF_name);

    zval property_name_default_value;
    ZVAL_UNDEF(&property_name_default_value);
    zend_string* property_name_name = zend_string_init("name", sizeof("name") - 1, 1);
    zend_declare_typed_property(class_entry,
                                property_name_name,
                                &property_name_default_value,
                                ZEND_ACC_PUBLIC,
                                NULL,
                                (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_STRING));
    zend_string_release(property_name_name);

    return class_entry;
}

static zend_class_entry* register_class_ReflectionEnum(zend_class_entry* class_entry_ReflectionClass)
{
    zend_class_entry ce, *class_entry;

    INIT_CLASS_ENTRY(ce, "ReflectionEnum", class_ReflectionEnum_methods);
    class_entry = zend_register_internal_class_with_flags(&ce, class_entry_ReflectionClass, 0);

    return class_entry;
}

static zend_class_entry* register_class_ReflectionEnumUnitCase(zend_class_entry* class_entry_ReflectionClassConstant)
{
    zend_class_entry ce, *class_entry;

    INIT_CLASS_ENTRY(ce, "ReflectionEnumUnitCase", class_ReflectionEnumUnitCase_methods);
    class_entry = zend_register_internal_class_with_flags(&ce, class_entry_ReflectionClassConstant, 0);

    return class_entry;
}

static zend_class_entry* register_class_ReflectionEnumBackedCase(zend_class_entry* class_entry_ReflectionEnumUnitCase)
{
    zend_class_entry ce, *class_entry;

    INIT_CLASS_ENTRY(ce, "ReflectionEnumBackedCase", class_ReflectionEnumBackedCase_methods);
    class_entry = zend_register_internal_class_with_flags(&ce, class_entry_ReflectionEnumUnitCase, 0);

    return class_entry;
}

static zend_class_entry* register_class_ReflectionFiber(void)
{
    zend_class_entry ce, *class_entry;

    INIT_CLASS_ENTRY(ce, "ReflectionFiber", class_ReflectionFiber_methods);
    class_entry = zend_register_internal_class_with_flags(&ce, NULL, ZEND_ACC_FINAL | ZEND_ACC_NOT_SERIALIZABLE);

    return class_entry;
}

static zend_class_entry* register_class_ReflectionConstant(zend_class_entry* class_entry_Reflector)
{
    zend_class_entry ce, *class_entry;

    INIT_CLASS_ENTRY(ce, "ReflectionConstant", class_ReflectionConstant_methods);
    class_entry = zend_register_internal_class_with_flags(
        &ce, NULL, ZEND_ACC_FINAL | ZEND_ACC_NO_DYNAMIC_PROPERTIES | ZEND_ACC_NOT_SERIALIZABLE);
    zend_class_implements(class_entry, 1, class_entry_Reflector);

    zval property_name_default_value;
    ZVAL_UNDEF(&property_name_default_value);
    zend_string* property_name_name = zend_string_init("name", sizeof("name") - 1, 1);
    zend_declare_typed_property(class_entry,
                                property_name_name,
                                &property_name_default_value,
                                ZEND_ACC_PUBLIC,
                                NULL,
                                (zend_type)ZEND_TYPE_INIT_MASK(MAY_BE_STRING));
    zend_string_release(property_name_name);

    return class_entry;
}
