/**
 * @file KeccakP-1600-SnP.h
 * @brief Maintain the original PHP and Zend implementation for the standalone Wasm runtime.
 * @details Original algorithms, licensing and copyright remain intact.
 * Target-specific behavior is documented by the adjacent port manifest.
 */
/*
Implementation by the Keccak, Keyak and Ketje Teams, namely, Guido Bertoni,
Joan Daemen, Michaël Peeters, Gilles Van Assche and Ronny Van Keer, hereby
denoted as "the implementer".

For more information, feedback or questions, please refer to our websites:
http://keccak.noekeon.org/
http://keyak.noekeon.org/
http://ketje.noekeon.org/

To the extent possible under law, the implementer has waived all copyright
and related or neighboring rights to the source code in this file.
http://creativecommons.org/publicdomain/zero/1.0/
*/

#ifndef _KeccakP_1600_SnP_h_
#define _KeccakP_1600_SnP_h_

/** For the documentation, see SnP-documentation.h.
 */

#define KeccakP1600_implementation "in-place 32-bit optimized implementation"
#define KeccakP1600_stateSizeInBytes 200
#define KeccakP1600_stateAlignment 8

#define KeccakP1600_StaticInitialize()
void KeccakP1600_Initialize(void* state);
void KeccakP1600_AddByte(void* state, unsigned char data, unsigned int offset);
void KeccakP1600_AddBytes(void* state, const unsigned char* data, unsigned int offset, unsigned int length);
void KeccakP1600_OverwriteBytes(void* state, const unsigned char* data, unsigned int offset, unsigned int length);
void KeccakP1600_OverwriteWithZeroes(void* state, unsigned int byteCount);
void KeccakP1600_Permute_Nrounds(void* state, unsigned int nrounds);
void KeccakP1600_Permute_12rounds(void* state);
void KeccakP1600_Permute_24rounds(void* state);
void KeccakP1600_ExtractBytes(const void* state, unsigned char* data, unsigned int offset, unsigned int length);
void KeccakP1600_ExtractAndAddBytes(
    const void* state, const unsigned char* input, unsigned char* output, unsigned int offset, unsigned int length);

#endif
