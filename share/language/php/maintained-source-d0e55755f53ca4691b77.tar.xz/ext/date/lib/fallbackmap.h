/**
 * @file fallbackmap.h
 * @brief Maintain the original PHP and Zend implementation for the standalone Wasm runtime.
 * @details Original algorithms, licensing and copyright remain intact.
 * Target-specific behavior is documented by the adjacent port manifest.
 */
{"sst", 0, -660 * 60, "Pacific/Apia"}, {"hst", 0, -600 * 60, "Pacific/Honolulu"},
    {"akst", 0, -540 * 60, "America/Anchorage"}, {"akdt", 1, -480 * 60, "America/Anchorage"},
    {"pst", 0, -480 * 60, "America/Los_Angeles"}, {"pdt", 1, -420 * 60, "America/Los_Angeles"},
    {"mst", 0, -420 * 60, "America/Denver"}, {"mdt", 1, -360 * 60, "America/Denver"},
    {"cst", 0, -360 * 60, "America/Chicago"}, {"cdt", 1, -300 * 60, "America/Chicago"},
    {"est", 0, -300 * 60, "America/New_York"}, {"vet", 0, -270 * 60, "America/Caracas"},
    {"edt", 1, -240 * 60, "America/New_York"}, {"ast", 0, -240 * 60, "America/Halifax"},
    {"adt", 1, -180 * 60, "America/Halifax"}, {"brt", 0, -180 * 60, "America/Sao_Paulo"},
    {"brst", 1, -120 * 60, "America/Sao_Paulo"}, {"azost", 0, -60 * 60, "Atlantic/Azores"},
    {"azodt", 1, 0 * 60, "Atlantic/Azores"}, {"gmt", 0, 0 * 60, "Europe/London"}, {"bst", 1, 60 * 60, "Europe/London"},
    {"cet", 0, 60 * 60, "Europe/Paris"}, {"cest", 1, 120 * 60, "Europe/Paris"}, {"eet", 0, 120 * 60, "Europe/Helsinki"},
    {"eest", 1, 180 * 60, "Europe/Helsinki"}, {"msk", 0, 180 * 60, "Europe/Moscow"},
    {"msd", 1, 240 * 60, "Europe/Moscow"}, {"gst", 0, 240 * 60, "Asia/Dubai"}, {"pkt", 0, 300 * 60, "Asia/Karachi"},
    {"ist", 0, 330 * 60, "Asia/Kolkata"}, {"npt", 0, 345 * 60, "Asia/Katmandu"},
    {"yekt", 1, 360 * 60, "Asia/Yekaterinburg"}, {"novst", 1, 420 * 60, "Asia/Novosibirsk"},
    {"krat", 0, 420 * 60, "Asia/Krasnoyarsk"}, {"cst", 0, 480 * 60, "Asia/Shanghai"},
    {"krast", 1, 480 * 60, "Asia/Krasnoyarsk"}, {"jst", 0, 540 * 60, "Asia/Tokyo"},
    {"est", 0, 600 * 60, "Australia/Melbourne"}, {"cst", 1, 630 * 60, "Australia/Adelaide"},
    {"est", 1, 660 * 60, "Australia/Melbourne"}, {"nzst", 0, 720 * 60, "Pacific/Auckland"},
    {"nzdt", 1, 780 * 60, "Pacific/Auckland"},
