# @file extconf.rb
# @brief Preserve original CRuby extension-discovery metadata for core-only builds.
# @details The selected WASI profile excludes pathname; this file lets upstream
# discovery emit its normal empty-extension link and diagnostic rules.
# frozen_string_literal: false
require "mkmf"
create_makefile("pathname")
