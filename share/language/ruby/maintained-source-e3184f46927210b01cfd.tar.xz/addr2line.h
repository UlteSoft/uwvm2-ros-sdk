/**
 * @file addr2line.h
 * @brief Maintain the original CRuby implementation for the standalone Wasm runtime.
 * @details Original algorithms, licensing and copyright remain intact.
 * Target-specific behavior is documented by the adjacent port manifest.
 */
#ifndef RUBY_ADDR2LINE_H
#define RUBY_ADDR2LINE_H
/**********************************************************************

  addr2line.h -

  $Author$

  Copyright (C) 2010 Shinichiro Hamaji

**********************************************************************/

#if (defined(USE_ELF) || defined(HAVE_MACH_O_LOADER_H))

#include <stdio.h>

void rb_dump_backtrace_with_lines(int num_traces, void** traces, FILE* errout);

#endif /* USE_ELF */

#endif /* RUBY_ADDR2LINE_H */
