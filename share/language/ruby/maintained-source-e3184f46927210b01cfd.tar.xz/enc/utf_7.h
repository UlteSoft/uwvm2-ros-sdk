/**
 * @file utf_7.h
 * @brief Maintain the original CRuby implementation for the standalone Wasm runtime.
 * @details Original algorithms, licensing and copyright remain intact.
 * Target-specific behavior is documented by the adjacent port manifest.
 */
#include "regenc.h"
/* dummy for unsupported, stateful encoding */
ENC_DUMMY("UTF-7");
ENC_ALIAS("CP65000", "UTF-7");
