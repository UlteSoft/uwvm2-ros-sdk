/**
 * @file gb2312.c
 * @brief Maintain the original CRuby implementation for the standalone Wasm runtime.
 * @details Original algorithms, licensing and copyright remain intact.
 * Target-specific behavior is documented by the adjacent port manifest.
 */
#include "regenc.h"

void Init_gb2312(void)
{
}

ENC_REPLICATE("GB2312", "EUC-KR")
ENC_ALIAS("EUC-CN", "GB2312")
ENC_ALIAS("eucCN", "GB2312")
ENC_REPLICATE("GB12345", "GB2312")
